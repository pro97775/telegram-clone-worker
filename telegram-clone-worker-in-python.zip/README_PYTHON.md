# Telegram Clone Worker (Python Edition)

A complete, 1-to-1 Python port of **Telegram Clone Worker** (`telegram-clone-worker-main`).
Replaces Cloudflare Workers + Cloudflare D1 with a zero-dependency **Python 3.10+ HTTP Server**, **SQLite (WAL mode)**, **PBKDF2/HMAC-SHA256 Auth**, **ThreadPoolExecutor Concurrency Limiter**, and a **1-Minute Background Cron Auto-Sync & Backfill Engine**.

---

## Project Architecture (Python Port Mapping)

| Original Cloudflare Worker File | Python Port File | Responsibility |
| :--- | :--- | :--- |
| `src/index.ts` | `app.py` | HTTP Fetch router (`/api/*`), static asset server, and 60s background cron scheduler (`run_tick`) |
| `src/auth/crypto.ts` | `telegram_clone/auth/crypto.py` | `PBKDF2-SHA256` (100,000 iterations), constant-time digest comparison, and `HMAC-SHA256` session tokens |
| `src/auth/handler.ts` | `telegram_clone/auth/handler.py` | `/api/auth/status`, `/api/auth/login`, `/api/auth/setup`, `/api/auth/remove`, and Bearer middleware |
| `src/db/bootstrap.ts` | `telegram_clone/db/bootstrap.py` | Thread-safe SQLite `Database` class (WAL + foreign keys) & automatic zero-config schema bootstrap |
| `src/db/queries.ts` | `telegram_clone/db/queries.py` | All SQLite queries for `bots`, `tasks`, `task_activity_log`, `saved_tasks`, `task_pending_messages`, and `updates` |
| `src/jobs/resolveRange.ts` | `telegram_clone/jobs/resolve_range.py` | `resolve_last_n` probe-and-delete latest message ID discovery |
| `src/jobs/tick.ts` | `telegram_clone/jobs/tick.py` | 1-minute live `getUpdates` polling, media/size filtering, pending buffer drain, and batch `copyMessages` backfiller |
| `src/routes/api/bots.ts` | `telegram_clone/routes/bots.py` | Bot verification, deep activity inspection, webhook sync/disconnect, and CRUD |
| `src/routes/api/chats.ts` | `telegram_clone/routes/chats.py` | Chat lookup, capability checklist, invite links, ban/unban/promote, and ad-hoc test copies |
| `src/routes/api/tasks.ts` | `telegram_clone/routes/tasks.py` | Task creation, range/cursor configuration, pause/resume, activity logs, and test copies |
| `src/routes/api/savedTasks.ts` | `telegram_clone/routes/saved_tasks.py` | Reusable task templates (`GET`, `POST`, `DELETE /api/saved-tasks`) |
| `src/shared/concurrencyPool.ts` | `telegram_clone/shared/concurrency_pool.py` | Bounded concurrency pool (`MAX_CONCURRENT_BOTS = 6`) via `ThreadPoolExecutor` |
| `src/shared/messageFilter.ts` | `telegram_clone/shared/message_filter.py` | Media metadata extraction, human-readable byte formatting, and filter evaluation |
| `src/shared/updateParser.ts` | `telegram_clone/shared/update_parser.py` | Plain-English Telegram update activity parser |
| `src/shared/rpcTypes.ts` | `telegram_clone/shared/rpc_types.py` | Shared RPC TypedDict definitions |
| `src/telegram/client.ts` | `telegram_clone/telegram/client.py` | Telegram Bot HTTP API client (`getMe`, `getUpdates`, `copyMessage`, `copyMessages`, etc.) |
| `src/telegram/capabilities.ts` | `telegram_clone/telegram/capabilities.py` | Chat administrator permission capability checklist |
| `src/telegram/errors.ts` | `telegram_clone/telegram/errors.py` | `TelegramApiError` classification (`rate_limited`, `unauthorized`, `bot_not_in_chat`, `insufficient_permissions`) |
| `src/telegram/types.ts` | `telegram_clone/telegram/types.py` | Telegram Bot API data structures |

---

## Running Standalone with Python

### 1. Build the Frontend Assets (Optional if already built in `dist/`)
```bash
npm install
npm run build
```

### 2. Start the Python Server
```bash
python3 app.py --port 8000 --db telegram_clone.db
```
Open `http://localhost:8000` in your browser. All database tables and indexes are created automatically on first launch.

### 3. Run Python Unit Tests
```bash
python3 -m unittest test_backend.py -v
```
