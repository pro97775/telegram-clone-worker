#!/usr/bin/env python3
"""
Telegram Clone Worker — Python Server & Scheduled Cron Engine
Ported 1:1 from src/index.ts (Cloudflare Workers + D1 SQLite -> Python 3 + SQLite).
"""
from __future__ import annotations
import argparse
import io
import json
import mimetypes
import os
import threading
import time
import urllib.parse
import zipfile
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from telegram_clone.auth.handler import (
    authenticate_api_request,
    handle_auth_login,
    handle_auth_remove,
    handle_auth_setup,
    handle_auth_status,
)
from telegram_clone.db.bootstrap import Database, ensure_database_bootstrap
from telegram_clone.jobs.tick import run_tick
from telegram_clone.routes.bots import (
    handle_delete_bot,
    handle_disconnect_bot_webhook,
    handle_inspect_bot,
    handle_list_bots,
    handle_sync_webhooks,
    handle_update_bot,
    handle_verify_bot,
)
from telegram_clone.routes.chats import (
    handle_ad_hoc_test_copy,
    handle_ban,
    handle_get_chat,
    handle_invite_link,
    handle_latest_message_id,
    handle_promote,
    handle_revoke_invite_link,
    handle_send_test_message,
    handle_unban,
)
from telegram_clone.routes.saved_tasks import (
    handle_create_saved_task,
    handle_delete_saved_task,
    handle_get_saved_task,
    handle_list_saved_tasks,
)
from telegram_clone.routes.tasks import (
    handle_create_task,
    handle_delete_task,
    handle_get_task_activity,
    handle_get_task_by_id,
    handle_list_all_tasks,
    handle_list_tasks,
    handle_patch_task,
    handle_test_copy,
)

ROOT_DIR = Path(__file__).resolve().parent
PYTHON_PROJECT_FILES = [
    "app.py",
    "requirements.txt",
    "README_PYTHON.md",
    "telegram_clone/__init__.py",
    "telegram_clone/auth/__init__.py",
    "telegram_clone/auth/crypto.py",
    "telegram_clone/auth/handler.py",
    "telegram_clone/db/__init__.py",
    "telegram_clone/db/bootstrap.py",
    "telegram_clone/db/queries.py",
    "telegram_clone/jobs/__init__.py",
    "telegram_clone/jobs/resolve_range.py",
    "telegram_clone/jobs/tick.py",
    "telegram_clone/routes/__init__.py",
    "telegram_clone/routes/bots.py",
    "telegram_clone/routes/chats.py",
    "telegram_clone/routes/saved_tasks.py",
    "telegram_clone/routes/tasks.py",
    "telegram_clone/shared/__init__.py",
    "telegram_clone/shared/concurrency_pool.py",
    "telegram_clone/shared/message_filter.py",
    "telegram_clone/shared/rpc_types.py",
    "telegram_clone/shared/update_parser.py",
    "telegram_clone/telegram/__init__.py",
    "telegram_clone/telegram/capabilities.py",
    "telegram_clone/telegram/client.py",
    "telegram_clone/telegram/errors.py",
    "telegram_clone/telegram/types.py",
    "test_backend.py",
]


def collect_python_project_files() -> list[dict[str, str]]:
    files: list[dict[str, str]] = []
    for rel_path in PYTHON_PROJECT_FILES:
        full_path = ROOT_DIR / rel_path
        if full_path.is_file():
            files.append(
                {
                    "path": rel_path,
                    "content": full_path.read_text(encoding="utf-8"),
                }
            )
    return files


def build_python_project_zip_bytes() -> bytes:
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        for rel_path in PYTHON_PROJECT_FILES:
            full_path = ROOT_DIR / rel_path
            if full_path.is_file():
                arc_name = "README.md" if rel_path == "README_PYTHON.md" else rel_path
                zf.write(full_path, f"telegram-clone-python/{arc_name}")

        # Include frontend source, migrations, and static assets so the zip is 100% self-contained
        for extra_rel in ["index.html", "package.json", "tsconfig.json", "vite.config.ts"]:
            p = ROOT_DIR / extra_rel
            if p.is_file():
                zf.write(p, f"telegram-clone-python/{extra_rel}")

        src_dir = ROOT_DIR / "src"
        if src_dir.is_dir():
            for p in sorted(src_dir.rglob("*")):
                if p.is_file():
                    zf.write(p, f"telegram-clone-python/{p.relative_to(ROOT_DIR)}")

        migrations_dir = ROOT_DIR / "migrations"
        if migrations_dir.is_dir():
            for p in sorted(migrations_dir.rglob("*.sql")):
                if p.is_file():
                    zf.write(p, f"telegram-clone-python/{p.relative_to(ROOT_DIR)}")
    return buf.getvalue()


def dispatch_api_request(
    method: str,
    pathname: str,
    query_params: dict[str, str],
    headers: dict[str, str],
    body: dict[str, Any],
    db: Database,
    origin: str = "http://localhost:3000",
) -> tuple[dict[str, Any], int]:
    """Routes /api/* requests identically to src/index.ts."""
    parts = [p for p in pathname.split("/") if p]
    if not parts or parts[0] != "api":
        return {"ok": False, "errorCode": 404, "description": "not found", "reason": "invalid_request"}, 404

    ensure_database_bootstrap(db)

    # Public health check
    if len(parts) >= 2 and parts[1] == "health":
        return {"ok": True, "data": {"status": "up", "runtime": "python"}}, 200

    # Public Python source inspection endpoint
    if len(parts) == 3 and parts[1] == "python-project" and parts[2] == "files" and method == "GET":
        return {"ok": True, "data": {"files": collect_python_project_files()}}, 200

    # Public authentication routes
    if len(parts) >= 2 and parts[1] == "auth":
        if len(parts) == 3 and parts[2] == "status" and method == "GET":
            return handle_auth_status(headers, db)
        if len(parts) == 3 and parts[2] == "login" and method == "POST":
            return handle_auth_login(body, db)
        if len(parts) == 3 and parts[2] == "setup" and method == "POST":
            return handle_auth_setup(headers, body, db)
        if len(parts) == 3 and parts[2] == "remove" and method == "POST":
            return handle_auth_remove(headers, db)
        return {"ok": False, "errorCode": 404, "description": "not found", "reason": "invalid_request"}, 404

    # Protect all remaining /api/* endpoints
    auth_error = authenticate_api_request(headers, db)
    if auth_error is not None:
        return auth_error

    bot_id = query_params.get("botId", "")
    bot_token = query_params.get("token", "")
    bot_telegram_id = query_params.get("botTelegramId", "")

    # /api/bots
    if len(parts) == 2 and parts[1] == "bots":
        if method == "GET":
            return handle_list_bots(db)

    # /api/bots/sync-webhooks
    if len(parts) == 3 and parts[1] == "bots" and parts[2] == "sync-webhooks" and method == "POST":
        return handle_sync_webhooks(db)

    # /api/bots/verify
    if len(parts) == 3 and parts[1] == "bots" and parts[2] == "verify" and method == "POST":
        return handle_verify_bot(body, db)

    # /api/bots/inspect
    if len(parts) == 3 and parts[1] == "bots" and parts[2] == "inspect" and method == "POST":
        return handle_inspect_bot(body, db)

    # /api/bots/disconnect-webhook
    if len(parts) == 3 and parts[1] == "bots" and parts[2] == "disconnect-webhook" and method == "POST":
        return handle_disconnect_bot_webhook(body, db)

    # /api/bots/:id
    if len(parts) == 3 and parts[1] == "bots":
        if method == "DELETE":
            return handle_delete_bot(db, parts[2])
        if method == "PATCH":
            return handle_update_bot(body, db, parts[2])

    # /api/bots/:botId/tasks
    if len(parts) == 4 and parts[1] == "bots" and parts[3] == "tasks":
        if method == "GET":
            return handle_list_tasks(db, parts[2])
        if method == "POST":
            return handle_create_task(body, db, parts[2], origin)

    # /api/bots/:botId/tasks/:taskId
    if len(parts) == 5 and parts[1] == "bots" and parts[3] == "tasks":
        if method == "PATCH":
            return handle_patch_task(body, db, parts[4])
        if method == "DELETE":
            return handle_delete_task(db, parts[4])

    # /api/bots/:botId/tasks/:taskId/test-copy
    if len(parts) == 6 and parts[1] == "bots" and parts[3] == "tasks" and parts[5] == "test-copy" and method == "POST":
        msg_id = int(body["messageId"]) if body.get("messageId") is not None else None
        return handle_test_copy(db, parts[2], parts[4], msg_id)

    # /api/tasks (all tasks across bots)
    if len(parts) == 2 and parts[1] == "tasks" and method == "GET":
        return handle_list_all_tasks(db)

    # /api/tasks/:taskId
    if len(parts) == 3 and parts[1] == "tasks":
        if method == "GET":
            return handle_get_task_by_id(db, parts[2])
        if method == "PATCH":
            return handle_patch_task(body, db, parts[2])
        if method == "DELETE":
            return handle_delete_task(db, parts[2])

    # /api/tasks/:taskId/activity
    if len(parts) == 4 and parts[1] == "tasks" and parts[3] == "activity" and method == "GET":
        return handle_get_task_activity(db, parts[2])

    # /api/chats/:chatId
    if len(parts) == 3 and parts[1] == "chats" and method == "GET":
        return handle_get_chat(db, urllib.parse.unquote(parts[2]), bot_id, bot_token, bot_telegram_id)

    # /api/chats/:chatId/latest-message-id
    if len(parts) == 4 and parts[1] == "chats" and parts[3] == "latest-message-id" and method == "GET":
        return handle_latest_message_id(db, urllib.parse.unquote(parts[2]), bot_id, bot_token)

    # /api/chats/:chatId/(invite-link|ban|unban|promote|send-test-message|test-copy|revoke-invite-link)
    if len(parts) == 4 and parts[1] == "chats" and method == "POST":
        chat_id = urllib.parse.unquote(parts[2])
        action = parts[3]
        if action == "invite-link":
            return handle_invite_link(db, chat_id, bot_id, bot_token)
        if action in ("ban", "unban"):
            user_id = int(body.get("userId", 0))
            return (
                handle_ban(db, chat_id, bot_id, user_id, bot_token)
                if action == "ban"
                else handle_unban(db, chat_id, bot_id, user_id, bot_token)
            )
        if action == "promote":
            user_id = int(body.get("userId", 0))
            rights = body.get("rights") or {}
            return handle_promote(db, chat_id, bot_id, user_id, rights, bot_token)
        if action == "send-test-message":
            text = str(body.get("text") or ".")
            return handle_send_test_message(db, chat_id, bot_id, text, bot_token)
        if action == "test-copy":
            dest_chat_id = str(body.get("destChatId", ""))
            msg_id = int(body["messageId"]) if body.get("messageId") is not None else None
            return handle_ad_hoc_test_copy(db, chat_id, bot_id, dest_chat_id, bot_token, msg_id)
        if action == "revoke-invite-link":
            invite_link = str(body.get("inviteLink", ""))
            return handle_revoke_invite_link(db, chat_id, bot_id, invite_link, bot_token)

    # /api/saved-tasks
    if len(parts) == 2 and parts[1] == "saved-tasks":
        if method == "GET":
            return handle_list_saved_tasks(db)
        if method == "POST":
            return handle_create_saved_task(body, db)

    # /api/saved-tasks/:id
    if len(parts) == 3 and parts[1] == "saved-tasks":
        if method == "GET":
            return handle_get_saved_task(db, parts[2])
        if method == "DELETE":
            return handle_delete_saved_task(db, parts[2])

    return {"ok": False, "errorCode": 404, "description": "not found", "reason": "invalid_request"}, 404


def create_http_handler(db: Database):
    dist_dir = ROOT_DIR / "dist"

    class RequestHandler(BaseHTTPRequestHandler):
        def log_message(self, format: str, *args: Any) -> None:
            # Silence noisy polling logs
            return

        def _handle(self, method: str) -> None:
            parsed = urllib.parse.urlparse(self.path)
            pathname = parsed.path

            # Special binary zip download route
            if pathname == "/api/python-project/download.zip" and method == "GET":
                zip_bytes = build_python_project_zip_bytes()
                self.send_response(200)
                self.send_header("Content-Type", "application/zip")
                self.send_header("Content-Disposition", 'attachment; filename="telegram-clone-python.zip"')
                self.send_header("Content-Length", str(len(zip_bytes)))
                self.end_headers()
                self.wfile.write(zip_bytes)
                return

            if pathname.startswith("/api/"):
                content_len = int(self.headers.get("Content-Length", "0") or "0")
                raw_body = self.rfile.read(content_len).decode("utf-8") if content_len > 0 else ""
                try:
                    body = json.loads(raw_body) if raw_body else {}
                    if not isinstance(body, dict):
                        body = {}
                except Exception:
                    body = {}

                query_params = dict(urllib.parse.parse_qsl(parsed.query, keep_blank_values=True))
                headers_dict = {k: v for k, v in self.headers.items()}
                host = self.headers.get("Host", "localhost:8000")
                origin = f"http://{host}"

                resp_obj, status_code = dispatch_api_request(
                    method,
                    pathname,
                    query_params,
                    headers_dict,
                    body,
                    db,
                    origin,
                )
                payload = json.dumps(resp_obj).encode("utf-8")
                self.send_response(status_code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(payload)))
                self.end_headers()
                self.wfile.write(payload)
                return

            # Static asset fallback from dist/ when running standalone
            if dist_dir.is_dir():
                rel = pathname.lstrip("/") or "index.html"
                candidate = (dist_dir / rel).resolve()
                if not str(candidate).startswith(str(dist_dir.resolve())) or not candidate.is_file():
                    candidate = dist_dir / "index.html"
                if candidate.is_file():
                    data = candidate.read_bytes()
                    ctype, _ = mimetypes.guess_type(str(candidate))
                    self.send_response(200)
                    self.send_header("Content-Type", ctype or "text/html; charset=utf-8")
                    self.send_header("Content-Length", str(len(data)))
                    self.end_headers()
                    self.wfile.write(data)
                    return

            not_found = b'{"ok":false,"errorCode":404,"description":"not found","reason":"invalid_request"}'
            self.send_response(404)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(not_found)))
            self.end_headers()
            self.wfile.write(not_found)

        def do_GET(self) -> None:
            self._handle("GET")

        def do_POST(self) -> None:
            self._handle("POST")

        def do_PATCH(self) -> None:
            self._handle("PATCH")

        def do_DELETE(self) -> None:
            self._handle("DELETE")

    return RequestHandler


def start_cron_loop(db: Database, interval_seconds: int = 60) -> threading.Thread:
    """Starts the background 1-minute scheduled cron worker thread."""

    def _loop() -> None:
        while True:
            time.sleep(interval_seconds)
            try:
                ensure_database_bootstrap(db)
                run_tick(db)
            except Exception as err:
                print(f"Scheduled cron tick error: {err}")

    t = threading.Thread(target=_loop, daemon=True, name="telegram-clone-cron")
    t.start()
    return t


def main() -> None:
    parser = argparse.ArgumentParser(description="Telegram Clone Worker (Python Backend)")
    parser.add_argument("--host", default="0.0.0.0", help="Bind host (default: 0.0.0.0)")
    parser.add_argument("--port", type=int, default=int(os.environ.get("PYTHON_PORT", "8000")), help="Bind port")
    parser.add_argument(
        "--db",
        default=os.environ.get("SQLITE_DB_PATH", str(ROOT_DIR / "telegram_clone.db")),
        help="Path to SQLite database file",
    )
    args = parser.parse_args()

    db = Database(args.db)
    ensure_database_bootstrap(db)
    start_cron_loop(db, interval_seconds=60)

    server = ThreadingHTTPServer((args.host, args.port), create_http_handler(db))
    print(f"Telegram Clone Worker (Python) listening on http://{args.host}:{args.port} (DB: {args.db})")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
