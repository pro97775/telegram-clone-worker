import express from "express";
import { spawn, type ChildProcess } from "node:child_process";
import http from "node:http";
import path from "node:path";
import { createServer as createViteServer } from "vite";

const PORT = 3000;
const PYTHON_PORT = Number(process.env.PYTHON_PORT || 8000);

let pythonProc: ChildProcess | null = null;

function startPythonServer(): Promise<void> {
  return new Promise((resolve) => {
    pythonProc = spawn("python3", ["app.py", "--host", "127.0.0.1", "--port", String(PYTHON_PORT)], {
      cwd: process.cwd(),
      stdio: ["ignore", "pipe", "pipe"],
      env: { ...process.env, PYTHONUNBUFFERED: "1" },
    });

    let resolved = false;
    const finish = () => {
      if (!resolved) {
        resolved = true;
        resolve();
      }
    };

    pythonProc.stdout?.on("data", (chunk: Buffer) => {
      const text = chunk.toString();
      process.stdout.write(`[python] ${text}`);
      if (text.includes("listening on")) {
        finish();
      }
    });

    pythonProc.stderr?.on("data", (chunk: Buffer) => {
      process.stderr.write(`[python:err] ${chunk.toString()}`);
    });

    pythonProc.on("exit", (code) => {
      console.warn(`Python backend exited with code ${code}`);
    });

    setTimeout(finish, 1500);
  });
}

process.on("SIGTERM", () => {
  pythonProc?.kill();
  process.exit(0);
});
process.on("SIGINT", () => {
  pythonProc?.kill();
  process.exit(0);
});

async function startServer() {
  await startPythonServer();

  const app = express();

  // Proxy all /api/* requests directly to the running Python 3 server
  app.use("/api", (req, res) => {
    const targetPath = req.originalUrl;
    const proxyReq = http.request(
      {
        hostname: "127.0.0.1",
        port: PYTHON_PORT,
        path: targetPath,
        method: req.method,
        headers: {
          ...req.headers,
          host: req.headers.host || `localhost:${PORT}`,
        },
      },
      (proxyRes) => {
        res.status(proxyRes.statusCode || 500);
        for (const [key, value] of Object.entries(proxyRes.headers)) {
          if (value !== undefined) {
            res.setHeader(key, value);
          }
        }
        proxyRes.pipe(res);
      },
    );

    proxyReq.on("error", (err) => {
      console.error("Error proxying to Python backend:", err);
      if (!res.headersSent) {
        res.status(502).json({
          ok: false,
          errorCode: 502,
          description: "Python backend unavailable",
          reason: "unknown",
        });
      }
    });

    req.pipe(proxyReq);
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*all", (_req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT} (proxying /api/* -> Python on :${PYTHON_PORT})`);
  });
}

startServer();
