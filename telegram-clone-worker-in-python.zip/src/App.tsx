import ClientApp from "./client/App";
import "./client/styles/tokens.css";

export default function App() {
  return <ClientApp />;
}
