import { useEffect, useState } from "react";
import { api } from "../lib/api";
import { useToast } from "./Toast";

interface PythonProjectFile {
  path: string;
  content: string;
}

export function PythonProjectModal({ onClose }: { onClose: () => void }) {
  const [files, setFiles] = useState<PythonProjectFile[]>([]);
  const [selectedPath, setSelectedPath] = useState<string>("app.py");
  const [loading, setLoading] = useState(true);
  const toast = useToast();

  useEffect(() => {
    let mounted = true;
    api.get<{ files: PythonProjectFile[] }>("/api/python-project/files").then((res) => {
      if (!mounted) return;
      if (res.ok && res.data.files) {
        setFiles(res.data.files);
        if (res.data.files.length > 0) {
          setSelectedPath(res.data.files[0].path);
        }
      }
      setLoading(false);
    });
    return () => {
      mounted = false;
    };
  }, []);

  const currentFile = files.find((f) => f.path === selectedPath) ?? files[0];

  function handleCopyFile() {
    if (!currentFile) return;
    navigator.clipboard.writeText(currentFile.content);
    toast.show("success", `Copied ${currentFile.path} to clipboard`);
  }

  return (
    <div className="drawer-backdrop is-open" style={{ zIndex: 900 }} onClick={onClose}>
      <div
        className="card"
        role="dialog"
        aria-labelledby="python-project-modal-title"
        style={{
          maxWidth: 960,
          width: "95%",
          height: "84vh",
          margin: "6vh auto 0",
          padding: 0,
          display: "flex",
          flexDirection: "column",
          overflow: "hidden",
          background: "var(--surface)",
          boxShadow: "0 24px 64px rgba(0,0,0,0.8)",
        }}
        onClick={(e) => e.stopPropagation()}
      >
        <div
          style={{
            padding: "16px 20px",
            borderBottom: "1px solid var(--border-subtle)",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            gap: 12,
            flexWrap: "wrap",
            background: "var(--surface-raised)",
          }}
        >
          <div>
            <h2 id="python-project-modal-title" style={{ fontSize: 16, fontWeight: 700, color: "var(--ink)" }}>
              🐍 Python Port Source & Standalone Archive
            </h2>
            <p className="text-muted" style={{ fontSize: 12, marginTop: 2 }}>
              1:1 Python 3 + SQLite port of Telegram Clone Worker (running live behind this console)
            </p>
          </div>
          <div className="row" style={{ gap: 8 }}>
            <a
              href="/api/python-project/download.zip"
              download="telegram-clone-python.zip"
              className="btn btn-primary btn-sm"
              style={{ textDecoration: "none" }}
            >
              ⬇ Download Python Project (.zip)
            </a>
            <button type="button" className="btn btn-secondary btn-sm" onClick={onClose}>
              ✕ Close
            </button>
          </div>
        </div>

        <div style={{ display: "flex", flex: 1, minHeight: 0 }}>
          {/* File tree sidebar */}
          <div
            style={{
              width: 260,
              borderRight: "1px solid var(--border-subtle)",
              overflowY: "auto",
              padding: "10px 8px",
              background: "var(--bg)",
            }}
          >
            <div
              style={{
                fontSize: 11,
                fontWeight: 700,
                textTransform: "uppercase",
                letterSpacing: "0.05em",
                color: "var(--muted)",
                padding: "4px 10px 8px",
              }}
            >
              Python Modules ({files.length})
            </div>
            {loading && (
              <div className="text-muted" style={{ padding: 12, fontSize: 12 }}>
                Loading Python files…
              </div>
            )}
            {files.map((f) => {
              const active = f.path === selectedPath;
              return (
                <button
                  key={f.path}
                  type="button"
                  onClick={() => setSelectedPath(f.path)}
                  style={{
                    display: "block",
                    width: "100%",
                    textAlign: "left",
                    padding: "7px 10px",
                    borderRadius: 6,
                    border: "none",
                    background: active ? "var(--surface-raised)" : "transparent",
                    color: active ? "var(--accent)" : "var(--ink)",
                    fontFamily: "var(--font-mono)",
                    fontSize: 12,
                    cursor: "pointer",
                    marginBottom: 2,
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                  }}
                >
                  {f.path}
                </button>
              );
            })}
          </div>

          {/* Code viewer */}
          <div style={{ flex: 1, display: "flex", flexDirection: "column", minWidth: 0 }}>
            {currentFile && (
              <>
                <div
                  style={{
                    padding: "10px 16px",
                    borderBottom: "1px solid var(--border-subtle)",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    background: "var(--surface)",
                  }}
                >
                  <span style={{ fontFamily: "var(--font-mono)", fontSize: 12.5, fontWeight: 600 }}>
                    {currentFile.path}
                  </span>
                  <button type="button" className="btn btn-secondary btn-sm" onClick={handleCopyFile}>
                    Copy File
                  </button>
                </div>
                <pre
                  style={{
                    flex: 1,
                    margin: 0,
                    padding: 16,
                    overflow: "auto",
                    fontFamily: "var(--font-mono)",
                    fontSize: 12,
                    lineHeight: 1.55,
                    color: "var(--ink)",
                    background: "var(--bg)",
                  }}
                >
                  <code>{currentFile.content}</code>
                </pre>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
