import test from "node:test";
import assert from "node:assert/strict";
import { execSync } from "node:child_process";
import { evaluateMessageFilter, extractMessageMetadata, formatBytes } from "./messageFilter";
import { parseTelegramUpdate } from "./updateParser";
import { getTaskDisplayInfo, isTaskActive, isTaskCompleted, isTaskPaused } from "../client/lib/useTasksContext";
import type { TaskSummary } from "./rpcTypes";

test("formatBytes formats byte sizes accurately", () => {
  assert.equal(formatBytes(0), "0 B");
  assert.equal(formatBytes(1024), "1 KB");
  assert.equal(formatBytes(1048576 * 5), "5 MB");
});

test("evaluateMessageFilter filters media types and sizes", () => {
  const msg = {
    message_id: 10,
    date: 1700000000,
    chat: { id: -1001, type: "channel" as const, title: "Source" },
    document: { file_id: "doc1", file_name: "archive.zip", file_size: 20480 },
  };
  const meta = extractMessageMetadata(msg);
  assert.equal(meta.type, "document");
  assert.equal(meta.name, "archive.zip");

  const pass = evaluateMessageFilter(msg, { mediaTypes: ["document"], minSizeBytes: 1024 });
  assert.equal(pass.matched, true);

  const fail = evaluateMessageFilter(msg, { mediaTypes: ["video"] });
  assert.equal(fail.matched, false);
});

test("parseTelegramUpdate summarizes channel posts and commands", () => {
  const postUpdate = {
    update_id: 500,
    channel_post: {
      message_id: 77,
      date: 1700000000,
      chat: { id: -10099, type: "channel" as const, title: "News Feed" },
      text: "Breaking update",
    },
  };
  const parsed = parseTelegramUpdate(postUpdate);
  assert.equal(parsed.kind, "channel_post");
  assert.ok(parsed.summary.includes("Breaking update"));
});

test("task state helpers classify active, paused, and completed tasks", () => {
  const baseTask: TaskSummary = {
    id: "t1",
    bot_id: "b1",
    label: "Source → Dest",
    source_chat_id: "-1001",
    source_chat_title: "Source",
    dest_chat_id: "-1002",
    dest_chat_title: "Dest",
    scope: "live_and_backfill",
    live_enabled: true,
    backfill_mode: "range",
    start_id: 1,
    end_id: 100,
    cursor: 25,
    total: 100,
    processed: 24,
    failed: 0,
    live_processed: 5,
    live_failed: 0,
    live_skipped: 0,
    filter_media_types: null,
    filter_min_size_bytes: null,
    filter_max_size_bytes: null,
    backfill_status: "running",
    pacing_batch_size: 60,
    stop_reason: null,
    stopped_at: null,
    rate_limited_until: null,
    created_at: 1700000000,
  };

  assert.equal(isTaskActive(baseTask), true);
  assert.equal(isTaskPaused(baseTask), false);
  assert.equal(isTaskCompleted(baseTask), false);

  const display = getTaskDisplayInfo(baseTask);
  assert.equal(display.routeText, "Source → Dest");
  assert.equal(display.isCustomLabel, false);
});

test("Python backend unit test suite (test_backend.py) passes completely", () => {
  const output = execSync("python3 -m unittest test_backend.py -v 2>&1", {
    encoding: "utf-8",
  });
  assert.ok(output.includes("OK"));
});
