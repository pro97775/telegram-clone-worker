"""Authentication and cryptography utilities."""
