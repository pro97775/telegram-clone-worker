"""Cryptographic utilities ported 1:1 from src/auth/crypto.ts."""
from __future__ import annotations
import base64
import hashlib
import hmac
import json
import secrets
import time
from typing import Any, TypedDict

PBKDF2_ITERATIONS = 100_000


class SessionTokenPayload(TypedDict):
    sub: str
    iat: int
    exp: int


def generate_salt() -> str:
    """Generates a random 16-byte hex salt."""
    return secrets.token_hex(16)


def hash_password(password: str, salt: str) -> str:
    """Derives a PBKDF2-SHA256 hash for a given password and salt."""
    derived = hashlib.pbkdf2_hmac(
        "sha256",
        password.encode("utf-8"),
        salt.encode("utf-8"),
        PBKDF2_ITERATIONS,
        dklen=32,
    )
    return derived.hex()


def timing_safe_string_compare(a: str, b: str) -> bool:
    """Cryptographically constant-time string comparison using SHA-256 fixed-size digests."""
    digest_a = hashlib.sha256(a.encode("utf-8")).digest()
    digest_b = hashlib.sha256(b.encode("utf-8")).digest()
    return hmac.compare_digest(digest_a, digest_b)


def _base64url_encode(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("ascii").rstrip("=")


def _base64url_decode(s: str) -> bytes:
    padding = "=" * ((4 - len(s) % 4) % 4)
    return base64.urlsafe_b64decode(s + padding)


def sign_session_token(payload: SessionTokenPayload, secret: str) -> str:
    """Signs a payload with HMAC-SHA256 and returns a compact URL-safe bearer token."""
    payload_bytes = json.dumps(payload, separators=(",", ":")).encode("utf-8")
    payload_part = _base64url_encode(payload_bytes)
    sig_bytes = hmac.new(
        secret.encode("utf-8"),
        payload_part.encode("utf-8"),
        hashlib.sha256,
    ).digest()
    sig_part = _base64url_encode(sig_bytes)
    return f"{payload_part}.{sig_part}"


def verify_session_token(token: str, secret: str) -> dict[str, Any]:
    """Validates a compact URL-safe bearer token against the secret and expiration."""
    try:
        parts = token.split(".")
        if len(parts) != 2:
            return {"valid": False}
        payload_part, sig_part = parts
        expected_sig = hmac.new(
            secret.encode("utf-8"),
            payload_part.encode("utf-8"),
            hashlib.sha256,
        ).digest()
        sig_bytes = _base64url_decode(sig_part)
        if not hmac.compare_digest(expected_sig, sig_bytes):
            return {"valid": False}
        payload_bytes = _base64url_decode(payload_part)
        payload = json.loads(payload_bytes.decode("utf-8"))
        now_ms = int(time.time() * 1000)
        if (
            not isinstance(payload, dict)
            or payload.get("sub") != "admin"
            or not isinstance(payload.get("exp"), (int, float))
            or not isinstance(payload.get("iat"), (int, float))
            or now_ms > payload["exp"]
        ):
            return {"valid": False}
        return {"valid": True, "payload": payload}
    except Exception:
        return {"valid": False}
