"""Authentication route handlers ported 1:1 from src/auth/handler.ts."""
from __future__ import annotations
import os
import time
from typing import Any
from ..db.bootstrap import Database
from ..shared.rpc_types import AuthMode, AuthSource
from .crypto import (
    generate_salt,
    hash_password,
    sign_session_token,
    timing_safe_string_compare,
    verify_session_token,
)

_ephemeral_signing_secret: str | None = None


def get_signing_secret(db: Database) -> str:
    """Retrieves or generates a stable HMAC secret for signing session tokens."""
    global _ephemeral_signing_secret
    env_secret = os.environ.get("AUTH_SECRET", "").strip()
    if env_secret:
        return env_secret
    try:
        row = db.first("SELECT value FROM app_settings WHERE key = 'auth_secret'")
        if row and row.get("value") and str(row["value"]).strip():
            return str(row["value"]).strip()
        new_secret = generate_salt() + generate_salt()
        db.run("INSERT OR IGNORE INTO app_settings (key, value) VALUES ('auth_secret', ?)", (new_secret,))
        stored = db.first("SELECT value FROM app_settings WHERE key = 'auth_secret'")
        return str(stored["value"]) if stored and stored.get("value") else new_secret
    except Exception as err:
        print(f"Failed to query or store auth_secret in SQLite: {err}")
        if not _ephemeral_signing_secret:
            _ephemeral_signing_secret = generate_salt() + generate_salt() + generate_salt()
        return _ephemeral_signing_secret


def get_auth_mode(db: Database) -> tuple[AuthMode, AuthSource]:
    """Determines current authentication mode and source."""
    env_password = os.environ.get("ADMIN_PASSWORD", "").strip()
    if env_password:
        return "enforced", "env"
    try:
        row = db.first("SELECT value FROM app_settings WHERE key = 'admin_password_hash'")
        if row and row.get("value") and str(row["value"]).strip():
            return "enforced", "d1"
    except Exception as err:
        print(f"Failed to check admin_password_hash in SQLite: {err}")
    return "open", "none"


def extract_bearer_token(headers: dict[str, str]) -> str | None:
    auth_header = headers.get("authorization") or headers.get("Authorization")
    if auth_header and auth_header.startswith("Bearer "):
        return auth_header[7:].strip()
    return None


def is_request_authenticated(headers: dict[str, str], db: Database) -> bool:
    token = extract_bearer_token(headers)
    if not token:
        return False
    secret = get_signing_secret(db)
    result = verify_session_token(token, secret)
    return bool(result.get("valid"))


def handle_auth_status(headers: dict[str, str], db: Database) -> tuple[dict[str, Any], int]:
    mode, source = get_auth_mode(db)
    authenticated = is_request_authenticated(headers, db)
    return {
        "ok": True,
        "data": {
            "mode": mode,
            "source": source,
            "authenticated": True if mode == "open" else authenticated,
        },
    }, 200


def handle_auth_login(body: dict[str, Any], db: Database) -> tuple[dict[str, Any], int]:
    raw_password = body.get("password")
    input_password = raw_password if isinstance(raw_password, str) else ""
    if not input_password:
        return {
            "ok": False,
            "errorCode": 400,
            "description": "Password is required",
            "reason": "invalid_request",
        }, 400
    if len(input_password) > 256:
        return {
            "ok": False,
            "errorCode": 400,
            "description": "Password exceeds maximum length (256 characters)",
            "reason": "invalid_request",
        }, 400

    mode, source = get_auth_mode(db)
    verified = False

    if source == "env":
        expected = os.environ.get("ADMIN_PASSWORD", "")
        verified = timing_safe_string_compare(input_password, expected)
    elif source == "d1":
        try:
            rows = db.all(
                "SELECT key, value FROM app_settings WHERE key IN ('admin_password_hash', 'admin_password_salt')"
            )
            hash_row = next((r for r in rows if r["key"] == "admin_password_hash"), None)
            salt_row = next((r for r in rows if r["key"] == "admin_password_salt"), None)
            if hash_row and salt_row:
                computed_hash = hash_password(input_password, str(salt_row["value"]))
                verified = timing_safe_string_compare(computed_hash, str(hash_row["value"]))
        except Exception as err:
            print(f"Failed to verify SQLite password: {err}")
    else:
        verified = True

    if not verified:
        return {
            "ok": False,
            "errorCode": 401,
            "description": "Invalid password",
            "reason": "unauthorized",
        }, 401

    secret = get_signing_secret(db)
    now_ms = int(time.time() * 1000)
    token = sign_session_token(
        {
            "sub": "admin",
            "iat": now_ms,
            "exp": now_ms + 30 * 24 * 60 * 60 * 1000,
        },
        secret,
    )
    return {"ok": True, "data": {"token": token}}, 200


def handle_auth_setup(headers: dict[str, str], body: dict[str, Any], db: Database) -> tuple[dict[str, Any], int]:
    mode, source = get_auth_mode(db)
    if source == "env":
        return {
            "ok": False,
            "errorCode": 400,
            "description": "Password is configured via environment variable ADMIN_PASSWORD",
            "reason": "invalid_request",
        }, 400

    if source == "d1":
        if not is_request_authenticated(headers, db):
            return {
                "ok": False,
                "errorCode": 401,
                "description": "Existing admin password must be authenticated to reconfigure",
                "reason": "unauthorized",
            }, 401

    raw_password = body.get("password")
    new_password = raw_password if isinstance(raw_password, str) else ""
    if not new_password or len(new_password) < 4:
        return {
            "ok": False,
            "errorCode": 400,
            "description": "Password must be at least 4 characters",
            "reason": "invalid_request",
        }, 400
    if len(new_password) > 256:
        return {
            "ok": False,
            "errorCode": 400,
            "description": "Password exceeds maximum length (256 characters)",
            "reason": "invalid_request",
        }, 400

    salt = generate_salt()
    pw_hash = hash_password(new_password, salt)
    db.batch(
        [
            ("INSERT OR REPLACE INTO app_settings (key, value) VALUES ('admin_password_hash', ?)", (pw_hash,)),
            ("INSERT OR REPLACE INTO app_settings (key, value) VALUES ('admin_password_salt', ?)", (salt,)),
        ]
    )

    secret = get_signing_secret(db)
    now_ms = int(time.time() * 1000)
    token = sign_session_token(
        {
            "sub": "admin",
            "iat": now_ms,
            "exp": now_ms + 30 * 24 * 60 * 60 * 1000,
        },
        secret,
    )
    return {"ok": True, "data": {"token": token}}, 200


def handle_auth_remove(headers: dict[str, str], db: Database) -> tuple[dict[str, Any], int]:
    mode, source = get_auth_mode(db)
    if source == "env":
        return {
            "ok": False,
            "errorCode": 400,
            "description": "Cannot remove password managed by ADMIN_PASSWORD environment variable",
            "reason": "invalid_request",
        }, 400
    if not is_request_authenticated(headers, db):
        return {
            "ok": False,
            "errorCode": 401,
            "description": "Authentication required",
            "reason": "unauthorized",
        }, 401

    db.batch(
        [
            ("DELETE FROM app_settings WHERE key = 'admin_password_hash'", ()),
            ("DELETE FROM app_settings WHERE key = 'admin_password_salt'", ()),
        ]
    )
    return {"ok": True, "data": {"status": "removed"}}, 200


def authenticate_api_request(headers: dict[str, str], db: Database) -> tuple[dict[str, Any], int] | None:
    mode, _ = get_auth_mode(db)
    if mode == "open":
        return None
    if is_request_authenticated(headers, db):
        return None
    return {
        "ok": False,
        "errorCode": 401,
        "description": "Admin authentication required",
        "reason": "unauthorized",
    }, 401
