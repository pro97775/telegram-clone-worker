"""SQLite Database layer ported 1:1 from src/db/."""
