"""Automatic SQLite Database Bootstrap Helper ported 1:1 from src/db/bootstrap.ts."""
from __future__ import annotations
import sqlite3
import threading
from typing import Any, Sequence


class Database:
    """Thread-safe SQLite wrapper emulating Cloudflare D1 semantics with WAL & foreign keys."""

    def __init__(self, db_path: str = "telegram_clone.db") -> None:
        self.db_path = db_path
        self._lock = threading.RLock()
        self._bootstrap_done = False
        # Persistent connection for in-memory databases; per-call or locked connection for file DB
        self._conn = sqlite3.connect(self.db_path, check_same_thread=False, isolation_level=None)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys = ON")
        if db_path != ":memory:":
            self._conn.execute("PRAGMA journal_mode = WAL")

    def run(self, sql: str, params: Sequence[Any] = ()) -> None:
        with self._lock:
            cur = self._conn.cursor()
            try:
                cur.execute(sql, tuple(params))
            finally:
                cur.close()

    def first(self, sql: str, params: Sequence[Any] = ()) -> dict[str, Any] | None:
        with self._lock:
            cur = self._conn.cursor()
            try:
                cur.execute(sql, tuple(params))
                row = cur.fetchone()
                return dict(row) if row is not None else None
            finally:
                cur.close()

    def all(self, sql: str, params: Sequence[Any] = ()) -> list[dict[str, Any]]:
        with self._lock:
            cur = self._conn.cursor()
            try:
                cur.execute(sql, tuple(params))
                rows = cur.fetchall()
                return [dict(r) for r in rows]
            finally:
                cur.close()

    def batch(self, statements: Sequence[tuple[str, Sequence[Any]]]) -> None:
        with self._lock:
            cur = self._conn.cursor()
            try:
                cur.execute("BEGIN")
                for sql, params in statements:
                    cur.execute(sql, tuple(params))
                cur.execute("COMMIT")
            except Exception:
                cur.execute("ROLLBACK")
                raise
            finally:
                cur.close()


def ensure_database_bootstrap(db: Database) -> None:
    """Ensures all tables and indexes exist in SQLite without manual migrations."""
    if db._bootstrap_done:
        return
    try:
        db.run(
            """CREATE TABLE IF NOT EXISTS app_settings (
                key TEXT PRIMARY KEY,
                value TEXT NOT NULL,
                created_at INTEGER NOT NULL DEFAULT (unixepoch())
            )"""
        )
        existing = db.first("SELECT name FROM sqlite_master WHERE type = 'table' AND name = 'tasks'")
        if existing:
            db._bootstrap_done = True
            return

        db.batch(
            [
                (
                    """CREATE TABLE IF NOT EXISTS app_settings (
                        key TEXT PRIMARY KEY,
                        value TEXT NOT NULL,
                        created_at INTEGER NOT NULL DEFAULT (unixepoch())
                    )""",
                    (),
                ),
                (
                    """CREATE TABLE IF NOT EXISTS bots (
                        id TEXT PRIMARY KEY,
                        token TEXT NOT NULL,
                        bot_id INTEGER NOT NULL,
                        bot_username TEXT NOT NULL,
                        label TEXT NOT NULL,
                        webhook_secret TEXT NOT NULL,
                        created_at INTEGER NOT NULL DEFAULT (unixepoch()),
                        last_update_id INTEGER NOT NULL DEFAULT 0
                    )""",
                    (),
                ),
                (
                    """CREATE TABLE IF NOT EXISTS tasks (
                        id TEXT PRIMARY KEY,
                        bot_id TEXT NOT NULL REFERENCES bots(id) ON DELETE CASCADE,
                        label TEXT NOT NULL,
                        source_chat_id TEXT NOT NULL,
                        source_chat_title TEXT,
                        dest_chat_id TEXT NOT NULL,
                        dest_chat_title TEXT,
                        scope TEXT NOT NULL CHECK (scope IN ('live', 'live_and_backfill', 'backfill_only')),
                        live_enabled INTEGER NOT NULL DEFAULT 0,
                        backfill_mode TEXT CHECK (backfill_mode IN ('range', 'lastN')),
                        start_id INTEGER,
                        end_id INTEGER,
                        cursor INTEGER,
                        total INTEGER,
                        processed INTEGER NOT NULL DEFAULT 0,
                        failed INTEGER NOT NULL DEFAULT 0,
                        backfill_status TEXT NOT NULL DEFAULT 'not_applicable'
                          CHECK (backfill_status IN ('not_applicable', 'pending', 'running', 'paused', 'complete', 'cancelled', 'failed')),
                        pacing_batch_size INTEGER NOT NULL DEFAULT 20,
                        created_at INTEGER NOT NULL DEFAULT (unixepoch()),
                        stop_reason TEXT,
                        stopped_at INTEGER,
                        lease_expires_at INTEGER,
                        rate_limited_until INTEGER,
                        live_processed INTEGER NOT NULL DEFAULT 0,
                        live_failed INTEGER NOT NULL DEFAULT 0,
                        filter_media_types TEXT,
                        filter_min_size_bytes INTEGER,
                        filter_max_size_bytes INTEGER,
                        live_skipped INTEGER NOT NULL DEFAULT 0
                    )""",
                    (),
                ),
                (
                    """CREATE TABLE IF NOT EXISTS task_activity_log (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
                        kind TEXT NOT NULL CHECK (kind IN ('live_forward', 'backfill_batch')),
                        detail TEXT,
                        ok INTEGER NOT NULL,
                        error TEXT,
                        at INTEGER NOT NULL DEFAULT (unixepoch())
                    )""",
                    (),
                ),
                (
                    """CREATE TABLE IF NOT EXISTS saved_tasks (
                        id TEXT PRIMARY KEY,
                        task_id TEXT REFERENCES tasks(id) ON DELETE SET NULL,
                        bot_token TEXT NOT NULL,
                        bot_label TEXT NOT NULL,
                        bot_username TEXT NOT NULL,
                        source_chat_id TEXT NOT NULL,
                        source_chat_title TEXT,
                        dest_chat_id TEXT NOT NULL,
                        dest_chat_title TEXT,
                        scope TEXT NOT NULL CHECK (scope IN ('live', 'live_and_backfill', 'backfill_only')),
                        backfill_mode TEXT CHECK (backfill_mode IN ('range', 'lastN')),
                        start_id INTEGER,
                        end_id INTEGER,
                        n INTEGER,
                        pacing_batch_size INTEGER NOT NULL,
                        created_at INTEGER NOT NULL DEFAULT (unixepoch()),
                        filter_media_types TEXT,
                        filter_min_size_bytes INTEGER,
                        filter_max_size_bytes INTEGER
                    )""",
                    (),
                ),
                (
                    """CREATE TABLE IF NOT EXISTS task_pending_messages (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        task_id TEXT NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
                        message_id INTEGER NOT NULL,
                        created_at INTEGER NOT NULL DEFAULT (unixepoch()),
                        media_type TEXT,
                        file_size INTEGER,
                        file_name TEXT
                    )""",
                    (),
                ),
                (
                    """CREATE TABLE IF NOT EXISTS updates (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        bot_id TEXT NOT NULL REFERENCES bots(id) ON DELETE CASCADE,
                        update_id INTEGER NOT NULL,
                        payload_json TEXT NOT NULL,
                        received_at INTEGER NOT NULL DEFAULT (unixepoch())
                    )""",
                    (),
                ),
                ("CREATE INDEX IF NOT EXISTS idx_tasks_bot_id ON tasks(bot_id)", ()),
                ("CREATE INDEX IF NOT EXISTS idx_tasks_source_chat ON tasks(bot_id, source_chat_id)", ()),
                (
                    "CREATE INDEX IF NOT EXISTS idx_tasks_backfill_running ON tasks(backfill_status) WHERE backfill_status = 'running'",
                    (),
                ),
                ("CREATE INDEX IF NOT EXISTS idx_task_activity_log_task_id ON task_activity_log(task_id, at DESC)", ()),
                ("CREATE INDEX IF NOT EXISTS idx_saved_tasks_task_id ON saved_tasks(task_id)", ()),
                (
                    "CREATE INDEX IF NOT EXISTS idx_pending_messages_task_id ON task_pending_messages(task_id, id ASC)",
                    (),
                ),
                ("CREATE INDEX IF NOT EXISTS idx_updates_bot_id ON updates(bot_id, received_at DESC)", ()),
            ]
        )
        db._bootstrap_done = True
    except Exception as err:
        print(f"Database bootstrap initialization check failed: {err}")
