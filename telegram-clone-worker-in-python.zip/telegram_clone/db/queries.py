"""Database queries ported 1:1 from src/db/queries.ts."""
from __future__ import annotations
import json
import time
from typing import Any
from .bootstrap import Database

ACTIVITY_LOG_KEEP_PER_TASK = 100


# ============================================================================
# Bots
# ============================================================================

def insert_bot(
    db: Database,
    row: dict[str, Any],
) -> None:
    db.run(
        """INSERT INTO bots (id, token, bot_id, bot_username, label, webhook_secret, last_update_id)
           VALUES (?, ?, ?, ?, ?, ?, 0)""",
        (
            row["id"],
            row["token"],
            row["bot_id"],
            row["bot_username"],
            row["label"],
            row["webhook_secret"],
        ),
    )


def list_bots_summary(db: Database) -> list[dict[str, Any]]:
    return db.all("SELECT id, bot_id, bot_username, label, created_at FROM bots ORDER BY created_at DESC")


def list_bots_with_secrets(db: Database) -> list[dict[str, Any]]:
    return db.all(
        "SELECT id, token, bot_id, bot_username, label, webhook_secret, last_update_id, created_at FROM bots ORDER BY created_at DESC"
    )


def update_bot_last_update_id(db: Database, bot_id: str, last_update_id: int) -> None:
    db.run("UPDATE bots SET last_update_id = ? WHERE id = ?", (last_update_id, bot_id))


def count_active_live_tasks_for_bot(db: Database, bot_id: str, exclude_task_id: str | None = None) -> int:
    query = "SELECT COUNT(*) as c FROM tasks WHERE bot_id = ? AND live_enabled = 1"
    params: list[Any] = [bot_id]
    if exclude_task_id:
        query += " AND id != ?"
        params.append(exclude_task_id)
    row = db.first(query, params)
    return int(row["c"]) if row and row.get("c") is not None else 0


def get_bot_with_secrets(db: Database, bot_id: str) -> dict[str, Any] | None:
    return db.first(
        "SELECT id, token, bot_id, bot_username, label, webhook_secret, last_update_id, created_at FROM bots WHERE id = ?",
        (bot_id,),
    )


def find_bot_by_webhook_secret(db: Database, bot_id: str, secret: str) -> dict[str, Any] | None:
    return db.first(
        "SELECT id, token, bot_id, bot_username, label, webhook_secret, created_at FROM bots WHERE id = ? AND webhook_secret = ?",
        (bot_id, secret),
    )


def find_bot_by_token_or_bot_id(
    db: Database,
    token: str,
    bot_telegram_id: int | None = None,
) -> dict[str, Any] | None:
    if bot_telegram_id is not None:
        return db.first(
            "SELECT id, token, bot_id, bot_username, label, webhook_secret, last_update_id, created_at FROM bots WHERE token = ? OR bot_id = ?",
            (token, bot_telegram_id),
        )
    return db.first(
        "SELECT id, token, bot_id, bot_username, label, webhook_secret, last_update_id, created_at FROM bots WHERE token = ?",
        (token,),
    )


def update_bot_label(db: Database, bot_id: str, label: str) -> None:
    db.run("UPDATE bots SET label = ? WHERE id = ?", (label, bot_id))


def delete_bot(db: Database, bot_id: str) -> None:
    db.run("DELETE FROM bots WHERE id = ?", (bot_id,))


# ============================================================================
# Tasks
# ============================================================================

def row_to_task(row: dict[str, Any]) -> dict[str, Any]:
    task: dict[str, Any] = {
        "id": str(row["id"]),
        "bot_id": str(row["bot_id"]),
        "label": str(row["label"]),
        "source_chat_id": str(row["source_chat_id"]),
        "source_chat_title": row.get("source_chat_title"),
        "dest_chat_id": str(row["dest_chat_id"]),
        "dest_chat_title": row.get("dest_chat_title"),
        "scope": row["scope"],
        "live_enabled": bool(row.get("live_enabled")),
        "backfill_mode": row.get("backfill_mode"),
        "start_id": row.get("start_id"),
        "end_id": row.get("end_id"),
        "cursor": row.get("cursor"),
        "total": row.get("total"),
        "processed": int(row.get("processed") or 0),
        "failed": int(row.get("failed") or 0),
        "live_processed": int(row.get("live_processed") or 0),
        "live_failed": int(row.get("live_failed") or 0),
        "live_skipped": int(row.get("live_skipped") or 0),
        "filter_media_types": row.get("filter_media_types"),
        "filter_min_size_bytes": row.get("filter_min_size_bytes"),
        "filter_max_size_bytes": row.get("filter_max_size_bytes"),
        "backfill_status": row["backfill_status"],
        "pacing_batch_size": int(row.get("pacing_batch_size") or 20),
        "stop_reason": row.get("stop_reason"),
        "stopped_at": row.get("stopped_at"),
        "rate_limited_until": row.get("rate_limited_until"),
        "created_at": int(row.get("created_at") or 0),
    }
    if row.get("pending_count") is not None:
        task["pending_count"] = int(row["pending_count"])
    return task


def insert_task(db: Database, t: dict[str, Any]) -> None:
    db.run(
        """INSERT INTO tasks (
            id, bot_id, label, source_chat_id, source_chat_title, dest_chat_id, dest_chat_title,
            scope, live_enabled, backfill_mode, start_id, end_id, cursor, total, backfill_status, pacing_batch_size,
            filter_media_types, filter_min_size_bytes, filter_max_size_bytes
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            t["id"],
            t["bot_id"],
            t["label"],
            t["source_chat_id"],
            t.get("source_chat_title"),
            t["dest_chat_id"],
            t.get("dest_chat_title"),
            t["scope"],
            1 if t.get("live_enabled") else 0,
            t.get("backfill_mode"),
            t.get("start_id"),
            t.get("end_id"),
            t.get("cursor"),
            t.get("total"),
            t["backfill_status"],
            t["pacing_batch_size"],
            t.get("filter_media_types"),
            t.get("filter_min_size_bytes"),
            t.get("filter_max_size_bytes"),
        ),
    )


def list_tasks_by_bot(db: Database, bot_id: str) -> list[dict[str, Any]]:
    rows = db.all("SELECT * FROM tasks WHERE bot_id = ? ORDER BY created_at DESC", (bot_id,))
    return [row_to_task(r) for r in rows]


def list_all_tasks_summary(db: Database) -> list[dict[str, Any]]:
    rows = db.all("SELECT * FROM tasks ORDER BY created_at DESC")
    return [row_to_task(r) for r in rows]


def get_task(db: Database, task_id: str) -> dict[str, Any] | None:
    row = db.first("SELECT * FROM tasks WHERE id = ?", (task_id,))
    return row_to_task(row) if row else None


def get_task_with_bot(db: Database, task_id: str) -> dict[str, Any] | None:
    row = db.first(
        """SELECT tasks.*,
                  COALESCE(bots.bot_username, 'unknown') as bot_username,
                  (SELECT COUNT(*) FROM task_pending_messages WHERE task_id = tasks.id) as pending_count
           FROM tasks
           LEFT JOIN bots ON bots.id = tasks.bot_id
           WHERE tasks.id = ?""",
        (task_id,),
    )
    if not row:
        return None
    result = row_to_task(row)
    result["bot_username"] = row.get("bot_username") or "unknown"
    return result


def list_tasks_for_source_chat(db: Database, chat_ids: list[str]) -> list[dict[str, Any]]:
    if not chat_ids:
        return []
    placeholders = ", ".join(["?"] * len(chat_ids))
    rows = db.all(
        f"""SELECT
                tasks.*,
                COALESCE(bots.bot_username, 'unknown') as bot_username,
                COALESCE(bots.label, 'Bot') as bot_label,
                (SELECT MAX(at) FROM task_activity_log WHERE task_id = tasks.id) AS last_activity_at
            FROM tasks
            LEFT JOIN bots ON bots.id = tasks.bot_id
            WHERE tasks.source_chat_id IN ({placeholders})
            ORDER BY tasks.created_at DESC""",
        chat_ids,
    )
    output: list[dict[str, Any]] = []
    for row in rows:
        task = row_to_task(row)
        cursor_val = task.get("cursor")
        resolved_last_id = (cursor_val - 1 if cursor_val is not None and cursor_val > 1 else None) or task.get("end_id")
        item = {
            **task,
            "bot_username": row.get("bot_username") or "unknown",
            "bot_label": row.get("bot_label") or "Bot",
            "last_copied_message_id": resolved_last_id,
            "last_activity_at": int(row["last_activity_at"]) if row.get("last_activity_at") is not None else None,
        }
        output.append(item)
    return output


def increment_task_processed(db: Database, task_id: str) -> None:
    db.run("UPDATE tasks SET processed = processed + 1 WHERE id = ?", (task_id,))


def find_duplicate_task(db: Database, bot_id: str, source_chat_id: str, dest_chat_id: str) -> dict[str, Any] | None:
    row = db.first(
        "SELECT * FROM tasks WHERE bot_id = ? AND source_chat_id = ? AND dest_chat_id = ?",
        (bot_id, source_chat_id, dest_chat_id),
    )
    return row_to_task(row) if row else None


def find_live_tasks_for_chat(db: Database, bot_id: str, source_chat_id: str) -> list[dict[str, Any]]:
    rows = db.all(
        """SELECT * FROM tasks WHERE bot_id = ? AND source_chat_id = ? AND live_enabled = 1
           AND scope IN ('live', 'live_and_backfill')""",
        (bot_id, source_chat_id),
    )
    return [row_to_task(r) for r in rows]


def list_running_backfill_tasks(db: Database) -> list[dict[str, Any]]:
    rows = db.all(
        """SELECT * FROM tasks WHERE backfill_status = 'running'
           AND (rate_limited_until IS NULL OR rate_limited_until <= unixepoch())
           ORDER BY bot_id, created_at, id"""
    )
    return [row_to_task(r) for r in rows]


def list_active_sync_tasks(db: Database) -> list[dict[str, Any]]:
    rows = db.all(
        """SELECT * FROM tasks
           WHERE (backfill_status = 'running' OR live_enabled = 1)
           AND (rate_limited_until IS NULL OR rate_limited_until <= unixepoch())
           AND stop_reason IS NULL
           ORDER BY bot_id, created_at, id"""
    )
    return [row_to_task(r) for r in rows]


def update_task_status(db: Database, task_id: str, patch: dict[str, Any]) -> None:
    sets: list[str] = []
    binds: list[Any] = []
    if "live_enabled" in patch and patch["live_enabled"] is not None:
        sets.append("live_enabled = ?")
        binds.append(1 if patch["live_enabled"] else 0)
    if "backfill_status" in patch and patch["backfill_status"] is not None:
        sets.append("backfill_status = ?")
        binds.append(patch["backfill_status"])
        if patch["backfill_status"] == "cancelled":
            sets.append("stopped_at = unixepoch()")
    if (
        patch.get("live_enabled") is True
        or patch.get("backfill_status") in ("running", "paused")
    ):
        sets.extend(["stop_reason = NULL", "stopped_at = NULL"])
    if not sets:
        return
    binds.append(task_id)
    db.run(f"UPDATE tasks SET {', '.join(sets)} WHERE id = ?", binds)


def update_task_config(db: Database, task_id: str, config: dict[str, Any]) -> None:
    sets: list[str] = []
    binds: list[Any] = []

    if "label" in config and config["label"] is not None:
        sets.append("label = ?")
        binds.append(config["label"])
    if "scope" in config and config["scope"] is not None:
        sets.append("scope = ?")
        binds.append(config["scope"])
    if "live_enabled" in config and config["live_enabled"] is not None:
        sets.append("live_enabled = ?")
        binds.append(1 if config["live_enabled"] else 0)
    if "backfill_mode" in config:
        sets.append("backfill_mode = ?")
        binds.append(config["backfill_mode"])
    if "backfill_status" in config and config["backfill_status"] is not None:
        sets.append("backfill_status = ?")
        binds.append(config["backfill_status"])
        if config["backfill_status"] == "cancelled":
            sets.append("stopped_at = unixepoch()")
    if "start_id" in config:
        sets.append("start_id = ?")
        binds.append(config["start_id"])
    if "end_id" in config:
        sets.append("end_id = ?")
        binds.append(config["end_id"])
    if "cursor" in config:
        sets.append("cursor = ?")
        binds.append(config["cursor"])
    if "total" in config:
        sets.append("total = ?")
        binds.append(config["total"])
    if config.get("reset_progress"):
        sets.extend(["processed = 0", "failed = 0"])
    if "filter_media_types" in config:
        sets.append("filter_media_types = ?")
        binds.append(config["filter_media_types"])
    if "filter_min_size_bytes" in config:
        sets.append("filter_min_size_bytes = ?")
        binds.append(config["filter_min_size_bytes"])
    if "filter_max_size_bytes" in config:
        sets.append("filter_max_size_bytes = ?")
        binds.append(config["filter_max_size_bytes"])

    if (
        config.get("live_enabled") is True
        or config.get("backfill_status") in ("running", "paused")
    ):
        sets.extend(["stop_reason = NULL", "stopped_at = NULL"])

    if sets:
        binds.append(task_id)
        db.run(f"UPDATE tasks SET {', '.join(sets)} WHERE id = ?", binds)

    if (
        config.get("clear_pending")
        or config.get("scope") == "backfill_only"
        or config.get("live_enabled") is False
    ):
        db.run("DELETE FROM task_pending_messages WHERE task_id = ?", (task_id,))


def extend_task_end_id(db: Database, task_id: str, message_id: int) -> None:
    db.run(
        """UPDATE tasks
           SET end_id = MAX(COALESCE(end_id, 0), ?),
               cursor = CASE WHEN cursor IS NULL THEN ? ELSE cursor END,
               total = CASE WHEN backfill_status != 'complete' AND start_id IS NOT NULL THEN MAX(COALESCE(end_id, 0), ?) - start_id + 1 ELSE total END
           WHERE id = ?""",
        (message_id, message_id, message_id, task_id),
    )


def advance_task_progress(
    db: Database,
    task_id: str,
    patch: dict[str, Any],
) -> dict[str, Any]:
    row = db.first(
        """UPDATE tasks
           SET cursor = ?,
               processed = ?,
               failed = ?,
               live_processed = COALESCE(?, live_processed),
               live_failed = COALESCE(?, live_failed),
               backfill_status = CASE
                 WHEN ? = 'complete' OR (end_id IS NOT NULL AND ? > end_id) THEN 'complete'
                 ELSE backfill_status
               END,
               stopped_at = CASE
                 WHEN (? = 'complete' OR (end_id IS NOT NULL AND ? > end_id)) AND live_enabled = 0 THEN unixepoch()
                 ELSE stopped_at
               END
           WHERE id = ?
           RETURNING backfill_status, end_id""",
        (
            patch["cursor"],
            patch["processed"],
            patch["failed"],
            patch.get("live_processed"),
            patch.get("live_failed"),
            patch.get("backfill_status"),
            patch["cursor"],
            patch.get("backfill_status"),
            patch["cursor"],
            task_id,
        ),
    )
    status = row["backfill_status"] if row and row.get("backfill_status") else "running"
    return {"backfill_status": status, "complete": status == "complete"}


def increment_live_counters(
    db: Database,
    task_id: str,
    processed_delta: int = 1,
    failed_delta: int = 0,
    skipped_delta: int = 0,
) -> None:
    db.run(
        """UPDATE tasks
           SET live_processed = live_processed + ?,
               live_failed = live_failed + ?,
               live_skipped = live_skipped + ?
           WHERE id = ?""",
        (processed_delta, failed_delta, skipped_delta, task_id),
    )


def delete_task(db: Database, task_id: str) -> None:
    db.run("DELETE FROM tasks WHERE id = ?", (task_id,))


def stop_tasks_for_bot(db: Database, bot_id: str, reason: str) -> list[dict[str, Any]]:
    return db.all(
        """UPDATE tasks
           SET live_enabled = 0,
               backfill_status = CASE WHEN backfill_status IN ('running','paused') THEN 'failed' ELSE backfill_status END,
               stop_reason = ?,
               stopped_at = unixepoch()
           WHERE bot_id = ?
             AND stop_reason IS NULL
             AND (live_enabled = 1 OR backfill_status IN ('running','paused'))
           RETURNING id, processed, failed""",
        (reason, bot_id),
    )


def stop_task(db: Database, task_id: str, reason: str) -> None:
    db.run(
        """UPDATE tasks
           SET live_enabled = 0,
               backfill_status = CASE WHEN backfill_status IN ('running','paused') THEN 'failed' ELSE backfill_status END,
               stop_reason = ?,
               stopped_at = unixepoch()
           WHERE id = ? AND stop_reason IS NULL""",
        (reason, task_id),
    )


def claim_task(db: Database, task_id: str, lease_seconds: int) -> dict[str, Any] | None:
    row = db.first(
        """UPDATE tasks
           SET lease_expires_at = unixepoch() + ?
           WHERE id = ?
             AND (backfill_status = 'running' OR live_enabled = 1)
             AND stop_reason IS NULL
             AND (lease_expires_at IS NULL OR lease_expires_at < unixepoch())
             AND (rate_limited_until IS NULL OR rate_limited_until <= unixepoch())
             AND NOT EXISTS (
               SELECT 1 FROM tasks sibling
               WHERE sibling.bot_id = tasks.bot_id
                 AND sibling.id <> tasks.id
                 AND sibling.lease_expires_at IS NOT NULL
                 AND sibling.lease_expires_at >= unixepoch()
             )
           RETURNING *""",
        (lease_seconds, task_id),
    )
    return row_to_task(row) if row else None


def pause_bot_for_rate_limit(db: Database, bot_id: str, until: int) -> None:
    db.run(
        """UPDATE tasks SET rate_limited_until = ?
           WHERE bot_id = ? AND (backfill_status = 'running' OR live_enabled = 1)""",
        (until, bot_id),
    )


def get_bot_rate_limit_stats(db: Database, bot_id: str) -> dict[str, Any]:
    now = int(time.time())
    cooldown_row = db.first(
        """SELECT MAX(rate_limited_until) as max_until
           FROM tasks
           WHERE bot_id = ? AND rate_limited_until > ?""",
        (bot_id, now),
    )
    max_until = cooldown_row.get("max_until") if cooldown_row else None

    history_row = db.first(
        """SELECT COUNT(*) as c
           FROM task_activity_log tal
           JOIN tasks t ON t.id = tal.task_id
           WHERE t.bot_id = ? AND tal.detail LIKE '%rate limited%' AND tal.at >= ?""",
        (bot_id, now - 86400),
    )
    events_24h = int(history_row["c"]) if history_row and history_row.get("c") is not None else 0

    return {
        "is_cooling_down": max_until is not None and int(max_until) > now,
        "cooldown_until": int(max_until) if max_until is not None else None,
        "cooldown_seconds_remaining": max(0, int(max_until) - now) if max_until is not None else 0,
        "events_last_24h": events_24h,
    }


def release_task_lease(db: Database, task_id: str) -> None:
    db.run("UPDATE tasks SET lease_expires_at = NULL WHERE id = ?", (task_id,))


# ============================================================================
# Activity log
# ============================================================================

def append_activity_log(db: Database, entry: dict[str, Any]) -> None:
    db.run(
        "INSERT INTO task_activity_log (task_id, kind, detail, ok, error) VALUES (?,?,?,?,?)",
        (
            entry["task_id"],
            entry["kind"],
            entry.get("detail"),
            1 if entry.get("ok") else 0,
            entry.get("error"),
        ),
    )


def list_activity_log(db: Database, task_id: str, limit: int = 50) -> list[dict[str, Any]]:
    return db.all(
        "SELECT * FROM task_activity_log WHERE task_id = ? ORDER BY at DESC LIMIT ?",
        (task_id, limit),
    )


def prune_activity_log(db: Database, task_id: str, keep_limit: int = ACTIVITY_LOG_KEEP_PER_TASK) -> None:
    db.run(
        """DELETE FROM task_activity_log WHERE task_id = ? AND id NOT IN (
             SELECT id FROM task_activity_log WHERE task_id = ? ORDER BY at DESC LIMIT ?
           )""",
        (task_id, task_id, keep_limit),
    )


def prune_all_activity_logs(db: Database, keep_limit: int = ACTIVITY_LOG_KEEP_PER_TASK) -> None:
    db.run(
        """DELETE FROM task_activity_log WHERE id NOT IN (
             SELECT id FROM (
               SELECT id, ROW_NUMBER() OVER (PARTITION BY task_id ORDER BY at DESC) as rn
               FROM task_activity_log
             ) WHERE rn <= ?
           )""",
        (keep_limit,),
    )


def insert_update(db: Database, bot_id: str, update_id: int, payload: Any) -> None:
    db.run(
        "INSERT INTO updates (bot_id, update_id, payload_json) VALUES (?, ?, ?)",
        (bot_id, update_id, json.dumps(payload)),
    )


# ============================================================================
# Saved Tasks
# ============================================================================

def insert_saved_task(db: Database, t: dict[str, Any]) -> None:
    db.run(
        """INSERT INTO saved_tasks (
            id, task_id, bot_token, bot_label, bot_username,
            source_chat_id, source_chat_title, dest_chat_id, dest_chat_title,
            scope, backfill_mode, start_id, end_id, n, pacing_batch_size,
            filter_media_types, filter_min_size_bytes, filter_max_size_bytes
        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            t["id"],
            t.get("task_id"),
            t["bot_token"],
            t["bot_label"],
            t["bot_username"],
            t["source_chat_id"],
            t.get("source_chat_title"),
            t["dest_chat_id"],
            t.get("dest_chat_title"),
            t["scope"],
            t.get("backfill_mode"),
            t.get("start_id"),
            t.get("end_id"),
            t.get("n"),
            t["pacing_batch_size"],
            t.get("filter_media_types"),
            t.get("filter_min_size_bytes"),
            t.get("filter_max_size_bytes"),
        ),
    )


def list_saved_tasks(db: Database) -> list[dict[str, Any]]:
    return db.all(
        """SELECT id, task_id, bot_label, bot_username,
                  substr(bot_token, 1, 6) || '…' || substr(bot_token, -4) AS token_preview,
                  source_chat_id, source_chat_title, dest_chat_id, dest_chat_title,
                  scope, backfill_mode, start_id, end_id, n, pacing_batch_size,
                  filter_media_types, filter_min_size_bytes, filter_max_size_bytes,
                  created_at
           FROM saved_tasks ORDER BY created_at DESC"""
    )


def get_saved_task(db: Database, saved_id: str) -> dict[str, Any] | None:
    return db.first(
        """SELECT id, task_id, bot_token, bot_label, bot_username,
                  substr(bot_token, 1, 6) || '…' || substr(bot_token, -4) AS token_preview,
                  source_chat_id, source_chat_title, dest_chat_id, dest_chat_title,
                  scope, backfill_mode, start_id, end_id, n, pacing_batch_size,
                  filter_media_types, filter_min_size_bytes, filter_max_size_bytes,
                  created_at
           FROM saved_tasks WHERE id = ?""",
        (saved_id,),
    )


def delete_saved_task(db: Database, saved_id: str) -> None:
    db.run("DELETE FROM saved_tasks WHERE id = ?", (saved_id,))


# ============================================================================
# Pending messages queue
# ============================================================================

def insert_pending_message(
    db: Database,
    task_id: str,
    message_id: int,
    media_type: str | None = None,
    file_size: int | None = None,
    file_name: str | None = None,
) -> None:
    db.run(
        """INSERT INTO task_pending_messages (task_id, message_id, media_type, file_size, file_name)
           VALUES (?, ?, ?, ?, ?)""",
        (task_id, message_id, media_type, file_size, file_name),
    )


def list_pending_messages(db: Database, task_id: str, limit: int = 50) -> list[dict[str, Any]]:
    return db.all(
        "SELECT * FROM task_pending_messages WHERE task_id = ? ORDER BY id ASC LIMIT ?",
        (task_id, limit),
    )


def count_pending_messages(db: Database, task_id: str) -> int:
    row = db.first("SELECT COUNT(*) as count FROM task_pending_messages WHERE task_id = ?", (task_id,))
    return int(row["count"]) if row and row.get("count") is not None else 0


def delete_pending_messages(db: Database, ids: list[int]) -> None:
    if not ids:
        return
    placeholders = ",".join(["?"] * len(ids))
    db.run(f"DELETE FROM task_pending_messages WHERE id IN ({placeholders})", ids)


def list_tasks_with_pending_messages(db: Database) -> list[dict[str, Any]]:
    rows = db.all(
        """SELECT DISTINCT tasks.* FROM tasks
           JOIN task_pending_messages ON task_pending_messages.task_id = tasks.id
           WHERE (tasks.rate_limited_until IS NULL OR tasks.rate_limited_until <= unixepoch())
             AND tasks.live_enabled = 1
             AND tasks.stop_reason IS NULL
             AND tasks.backfill_status != 'running'"""
    )
    return [row_to_task(r) for r in rows]
