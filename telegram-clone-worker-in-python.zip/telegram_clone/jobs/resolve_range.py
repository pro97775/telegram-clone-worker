"""Probe-and-delete range resolver ported 1:1 from src/jobs/resolveRange.ts."""
from __future__ import annotations
from typing import TypedDict
from ..telegram.client import TelegramClient


class ResolvedRange(TypedDict):
    startId: int
    endId: int
    cleanupOk: bool


def resolve_last_n(client: TelegramClient, source_chat_id: str, n: int) -> ResolvedRange:
    """Send a throwaway message to learn the chat's current highest message id, then delete it."""
    probe = client.send_message(source_chat_id, ".")
    cleanup_ok = True
    try:
        client.delete_message(source_chat_id, int(probe["message_id"]))
    except Exception:
        cleanup_ok = False
    latest_real_id = int(probe["message_id"]) - 1
    return {
        "startId": max(1, latest_real_id - n + 1),
        "endId": latest_real_id,
        "cleanupOk": cleanup_ok,
    }
