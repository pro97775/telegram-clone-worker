"""Scheduled 1-minute tick engine ported 1:1 from src/jobs/tick.ts."""
from __future__ import annotations
import random
import re
import time
from typing import Any
from ..db.bootstrap import Database
from ..db.queries import (
    advance_task_progress,
    append_activity_log,
    claim_task,
    delete_pending_messages,
    get_bot_with_secrets,
    increment_live_counters,
    insert_pending_message,
    list_active_sync_tasks,
    list_pending_messages,
    list_tasks_with_pending_messages,
    pause_bot_for_rate_limit,
    prune_activity_log,
    release_task_lease,
    stop_task,
    stop_tasks_for_bot,
    update_bot_last_update_id,
)
from ..shared.concurrency_pool import run_with_concurrency
from ..shared.message_filter import (
    evaluate_message_filter,
    extract_message_metadata,
    format_bytes,
    get_media_icon,
)
from ..telegram.client import TelegramClient
from ..telegram.errors import TelegramApiError

MAX_CONCURRENT_BOTS = 6
LEASE_SECONDS = 55
MAX_BATCH_IDS = 100
RATE_LIMIT_COOLDOWN_MIN_SECONDS = 30
RATE_LIMIT_COOLDOWN_MAX_SECONDS = 300


def run_tick(db: Database) -> None:
    """Executes one 1-minute synchronization & backfill cycle across all active bots."""
    tick_started_at_ms = int(time.time() * 1000)
    tasks = list_active_sync_tasks(db)

    groups: list[list[dict[str, Any]]] = []
    for task in tasks:
        if groups and groups[-1][0]["bot_id"] == task["bot_id"]:
            groups[-1].append(task)
        else:
            groups.append([task])

    total_bots = len(groups)
    is_smooth_mode = total_bots <= 50
    max_tick_wall_time_ms = 50_000 if is_smooth_mode else 38_000

    if not is_smooth_mode and groups:
        offset = (tick_started_at_ms // 60_000) % len(groups)
        groups = groups[offset:] + groups[:offset]

    batches_run = 0

    def _process_group(group_tasks: list[dict[str, Any]], _idx: int) -> None:
        nonlocal batches_run
        if not is_smooth_mode and (int(time.time() * 1000) - tick_started_at_ms) > max_tick_wall_time_ms:
            return

        bot_id = group_tasks[0]["bot_id"]
        try:
            bot = get_bot_with_secrets(db, bot_id)
            if not bot:
                return
            client = TelegramClient(bot["token"])

            # 1. Pull-based Auto-Sync: Check for new Telegram updates if any task has live_enabled = True
            has_live = any(t.get("live_enabled") for t in group_tasks)
            if has_live:
                try:
                    max_pull_pages = 5
                    page = 0
                    last_uid = int(bot.get("last_update_id") or 0)
                    current_offset = last_uid + 1 if last_uid > 0 else None
                    max_update_id = last_uid

                    while page < max_pull_pages:
                        page += 1
                        updates = client.get_updates(
                            {
                                "offset": current_offset,
                                "limit": 100,
                                "allowed_updates": ["channel_post"],
                            }
                        )
                        if not updates:
                            break

                        for update in updates:
                            uid = int(update.get("update_id", 0))
                            if uid > max_update_id:
                                max_update_id = uid

                            post = update.get("channel_post")
                            if not post:
                                continue

                            chat_str = str(post.get("chat", {}).get("id", ""))
                            matching_tasks = [
                                t
                                for t in group_tasks
                                if t["source_chat_id"] == chat_str and t.get("live_enabled")
                            ]
                            if not matching_tasks:
                                continue

                            meta = extract_message_metadata(post)
                            icon = get_media_icon(meta["type"])
                            size_str = format_bytes(meta.get("size")) if meta.get("size") else ""
                            name_str = f"({meta['name']})" if meta.get("name") else ""
                            file_desc = " ".join(p for p in [icon, size_str, name_str] if p)

                            for t in matching_tasks:
                                if t.get("cursor") is None and t.get("backfill_status") == "not_applicable":
                                    t["cursor"] = int(post["message_id"])

                                raw_media_types = t.get("filter_media_types")
                                filter_media_types = (
                                    [s.strip() for s in str(raw_media_types).split(",") if s.strip()]
                                    if raw_media_types
                                    else None
                                )
                                eval_result = evaluate_message_filter(
                                    post,
                                    {
                                        "mediaTypes": filter_media_types,
                                        "minSizeBytes": t.get("filter_min_size_bytes"),
                                        "maxSizeBytes": t.get("filter_max_size_bytes"),
                                    },
                                )

                                if not eval_result["matched"]:
                                    increment_live_counters(db, t["id"], 0, 0, 1)
                                    t["live_skipped"] = int(t.get("live_skipped") or 0) + 1
                                    append_activity_log(
                                        db,
                                        {
                                            "task_id": t["id"],
                                            "kind": "live_forward",
                                            "detail": f"{file_desc} · msg #{post['message_id']} skipped: {eval_result.get('reason')}",
                                            "ok": False,
                                            "error": f"Filtered: {eval_result.get('reason')}",
                                        },
                                    )
                                    continue

                                insert_pending_message(
                                    db,
                                    t["id"],
                                    int(post["message_id"]),
                                    meta["type"],
                                    meta.get("size"),
                                    meta.get("name"),
                                )
                                if t.get("backfill_status") == "running":
                                    append_activity_log(
                                        db,
                                        {
                                            "task_id": t["id"],
                                            "kind": "live_forward",
                                            "detail": f"⏳ Queued in buffer: {file_desc} · msg #{post['message_id']} (waiting for backfill to finish)",
                                            "ok": True,
                                        },
                                    )

                        current_offset = max_update_id + 1
                        if len(updates) < 100:
                            break

                    if max_update_id > int(bot.get("last_update_id") or 0):
                        update_bot_last_update_id(db, bot["id"], max_update_id)
                        bot["last_update_id"] = max_update_id
                except Exception as exc:
                    if isinstance(exc, TelegramApiError):
                        if exc.error_code == 401 or exc.reason == "unauthorized":
                            stopped_tasks = stop_tasks_for_bot(db, bot["id"], "unauthorized")
                            for st in stopped_tasks:
                                append_activity_log(
                                    db,
                                    {
                                        "task_id": st["id"],
                                        "kind": "live_forward",
                                        "detail": "Stopped: Bot token unauthorized (401). Bot token may have been revoked or changed in @BotFather.",
                                        "ok": False,
                                        "error": "401 Unauthorized",
                                    },
                                )
                            return
                        if exc.error_code == 409 or "webhook" in str(exc).lower():
                            try:
                                client.delete_webhook()
                            except Exception:
                                pass
                            return
                    print(f"tick: getUpdates failed for bot {bot['bot_username']}: {exc}")

            # 2. Process tasks that have messages to copy (cursor <= end_id)
            for task in group_tasks:
                if (
                    task.get("backfill_status") == "running"
                    and task.get("cursor") is not None
                    and task.get("end_id") is not None
                    and int(task["cursor"]) > int(task["end_id"])
                ):
                    res = advance_task_progress(
                        db,
                        task["id"],
                        {
                            "cursor": task["cursor"],
                            "processed": task["processed"],
                            "failed": task["failed"],
                            "backfill_status": "complete",
                        },
                    )
                    task["backfill_status"] = res["backfill_status"]

                if (
                    task.get("cursor") is None
                    or task.get("end_id") is None
                    or int(task["cursor"]) > int(task["end_id"])
                ):
                    continue

                claimed = claim_task(db, task["id"], LEASE_SECONDS)
                if not claimed:
                    continue

                try:
                    batches_run += 1
                    skip_bot_for_rest = process_one_batch(db, claimed, bot, client)
                    if skip_bot_for_rest:
                        break
                except Exception as exc:
                    print(f"tick: task {claimed['id']} failed: {exc}")
                finally:
                    release_task_lease(db, claimed["id"])
        except Exception as exc:
            print(f"tick: bot {bot_id} group failed: {exc}")

    run_with_concurrency(groups, MAX_CONCURRENT_BOTS, _process_group)

    tasks_with_pending = list_tasks_with_pending_messages(db)
    for p_task in tasks_with_pending:
        try:
            drain_pending_messages_for_task(db, p_task)
        except Exception as exc:
            print(f"tick: draining pending messages for task {p_task['id']} failed: {exc}")


def drain_pending_messages_for_task(db: Database, task: dict[str, Any]) -> bool:
    """Drains buffered live messages in chronological order once backfill completes."""
    if task.get("backfill_status") == "running":
        return False

    pending = list_pending_messages(db, task["id"], 60)
    if not pending:
        return False

    bot = get_bot_with_secrets(db, task["bot_id"])
    if not bot:
        return False

    client = TelegramClient(bot["token"])

    for item in pending:
        icon = get_media_icon(item.get("media_type") or "text")
        size_str = format_bytes(item.get("file_size")) if item.get("file_size") else ""
        name_str = f"({item['file_name']})" if item.get("file_name") else ""
        file_desc = " ".join(p for p in [icon, size_str, name_str] if p)

        try:
            client.copy_message(task["dest_chat_id"], task["source_chat_id"], int(item["message_id"]))
            delete_pending_messages(db, [int(item["id"])])
            increment_live_counters(db, task["id"], 1, 0, 0)
            append_activity_log(
                db,
                {
                    "task_id": task["id"],
                    "kind": "live_forward",
                    "detail": f"Copied {file_desc} · msg #{item['message_id']} (delivered from live queue)",
                    "ok": True,
                },
            )
        except Exception as exc:
            error_str = str(exc)
            if isinstance(exc, TelegramApiError) and exc.reason == "rate_limited":
                wait_seconds = min(
                    max(exc.retry_after or 0, RATE_LIMIT_COOLDOWN_MIN_SECONDS),
                    RATE_LIMIT_COOLDOWN_MAX_SECONDS,
                )
                pause_bot_for_rate_limit(db, task["bot_id"], int(time.time()) + wait_seconds)
                return True
            if isinstance(exc, TelegramApiError) and exc.reason == "unauthorized":
                stop_tasks_for_bot(db, task["bot_id"], "unauthorized")
                return True
            if isinstance(exc, TelegramApiError) and (
                "not found" in error_str.lower()
                or "message to forward not found" in error_str.lower()
                or "message to copy not found" in error_str.lower()
            ):
                delete_pending_messages(db, [int(item["id"])])
                append_activity_log(
                    db,
                    {
                        "task_id": task["id"],
                        "kind": "live_forward",
                        "detail": f"msg #{item['message_id']}: not found in source, removed from queue",
                        "ok": False,
                        "error": error_str,
                    },
                )
            break
    return False


def process_one_batch(
    db: Database,
    task: dict[str, Any],
    bot_param: dict[str, Any] | None = None,
    client_param: TelegramClient | None = None,
) -> bool:
    """Processes one batch of backfill message IDs for a task."""
    if task.get("cursor") is None or task.get("end_id") is None:
        return False
    bot = bot_param or get_bot_with_secrets(db, task["bot_id"])
    if not bot:
        return False
    client = client_param or TelegramClient(bot["token"])

    cursor = int(task["cursor"])
    end_id = int(task["end_id"])
    pacing_batch_size = int(task.get("pacing_batch_size") or 60)

    batch_started_at_ms = int(time.time() * 1000)
    batch_end = min(cursor + pacing_batch_size - 1, end_id, cursor + MAX_BATCH_IDS - 1)
    message_ids = list(range(cursor, batch_end + 1))

    try:
        results = client.copy_messages(task["dest_chat_id"], task["source_chat_id"], message_ids)
        succeeded = len(results)
    except Exception as exc:
        if isinstance(exc, TelegramApiError) and exc.reason == "rate_limited":
            wait_seconds = min(
                max(exc.retry_after or 0, RATE_LIMIT_COOLDOWN_MIN_SECONDS),
                RATE_LIMIT_COOLDOWN_MAX_SECONDS,
            )
            pause_bot_for_rate_limit(db, task["bot_id"], int(time.time()) + wait_seconds)
            append_activity_log(
                db,
                {
                    "task_id": task["id"],
                    "kind": "backfill_batch",
                    "detail": f"ids {cursor}-{batch_end}: rate limited, pausing bot for {wait_seconds}s",
                    "ok": True,
                },
            )
            return True
        if isinstance(exc, TelegramApiError) and exc.reason == "unauthorized":
            stopped = stop_tasks_for_bot(db, task["bot_id"], "unauthorized")
            for t in stopped:
                append_activity_log(
                    db,
                    {
                        "task_id": t["id"],
                        "kind": "backfill_batch",
                        "detail": f"bot token unauthorized (401) — task auto-stopped ({t['processed']} copied, {t['failed']} failed before stopping)",
                        "ok": False,
                        "error": str(exc),
                    },
                )
            return True

        msg_lower = str(exc).lower()
        if isinstance(exc, TelegramApiError) and (
            "no messages to forward" in msg_lower
            or re.search(r"failed to send message #\d+\b", str(exc), re.IGNORECASE)
        ):
            succeeded = 0
        elif isinstance(exc, TelegramApiError) and exc.reason in ("bot_not_in_chat", "insufficient_permissions"):
            stop_task(db, task["id"], exc.reason)
            append_activity_log(
                db,
                {
                    "task_id": task["id"],
                    "kind": "backfill_batch",
                    "detail": f"ids {cursor}-{batch_end}: {exc.reason} — task auto-stopped",
                    "ok": False,
                    "error": str(exc),
                },
            )
            return False
        else:
            reason = exc.reason if isinstance(exc, TelegramApiError) else "unexpected error"
            append_activity_log(
                db,
                {
                    "task_id": task["id"],
                    "kind": "backfill_batch",
                    "detail": f"ids {cursor}-{batch_end}: {reason}, resuming next tick",
                    "ok": False,
                    "error": str(exc),
                },
            )
            return False

    batch_duration_ms = int(time.time() * 1000) - batch_started_at_ms
    skipped = len(message_ids) - succeeded
    new_cursor = batch_end + 1
    was_backfilling = task.get("backfill_status") != "complete"

    new_processed = int(task.get("processed") or 0)
    new_failed = int(task.get("failed") or 0)
    new_live_processed = int(task.get("live_processed") or 0)
    new_live_failed = int(task.get("live_failed") or 0)

    if was_backfilling:
        new_processed += succeeded
        new_failed += skipped
    else:
        new_live_processed += succeeded
        new_live_failed += skipped

    progress_result = advance_task_progress(
        db,
        task["id"],
        {
            "cursor": new_cursor,
            "processed": new_processed,
            "failed": new_failed,
            "live_processed": new_live_processed,
            "live_failed": new_live_failed,
        },
    )

    just_completed_backfill = was_backfilling and progress_result["complete"]
    is_live_scope = task["scope"] == "live" or (task["scope"] == "live_and_backfill" and not was_backfilling)

    complete_suffix = " (backfill complete)" if just_completed_backfill else ""
    append_activity_log(
        db,
        {
            "task_id": task["id"],
            "kind": "live_forward" if is_live_scope else "backfill_batch",
            "detail": f"ids {cursor}-{batch_end}: {succeeded} ok, {skipped} skipped, took {batch_duration_ms}ms{complete_suffix}",
            "ok": True,
            "error": f"{skipped} message(s) in this range skipped by Telegram (not found / can't be copied)"
            if skipped > 0
            else None,
        },
    )

    if progress_result["complete"] or random.random() < 0.05:
        prune_activity_log(db, task["id"])

    return False
