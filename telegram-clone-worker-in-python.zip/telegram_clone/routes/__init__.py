"""API Route handlers ported 1:1 from src/routes/api/."""
