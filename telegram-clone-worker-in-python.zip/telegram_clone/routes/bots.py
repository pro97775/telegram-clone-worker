"""Bots API route handlers ported 1:1 from src/routes/api/bots.ts."""
from __future__ import annotations
import time
import uuid
from typing import Any
from ..db.bootstrap import Database
from ..db.queries import (
    delete_bot,
    find_bot_by_token_or_bot_id,
    get_bot_rate_limit_stats,
    get_bot_with_secrets,
    insert_bot,
    list_bots_summary,
    list_bots_with_secrets,
    list_tasks_by_bot,
    update_bot_label,
)
from ..shared.update_parser import parse_telegram_update
from ..telegram.client import TelegramClient
from ..telegram.errors import TelegramApiError, to_result


def handle_list_bots(db: Database) -> tuple[dict[str, Any], int]:
    bots = list_bots_summary(db)
    return {"ok": True, "data": bots}, 200


def handle_sync_webhooks(db: Database) -> tuple[dict[str, Any], int]:
    bots = list_bots_with_secrets(db)
    webhooks_deleted = 0
    errors: list[str] = []

    for bot in bots:
        client = TelegramClient(bot["token"])
        try:
            client.delete_webhook(False)
            webhooks_deleted += 1
        except Exception as exc:
            errors.append(f"@{bot['bot_username']}: {exc}")

    data: dict[str, Any] = {
        "totalBots": len(bots),
        "webhooksDeleted": webhooks_deleted,
    }
    if errors:
        data["errors"] = errors
    return {"ok": True, "data": data}, 200


def handle_verify_bot(body: dict[str, Any], db: Database) -> tuple[dict[str, Any], int]:
    raw_token = body.get("token")
    token = raw_token.strip() if isinstance(raw_token, str) else ""
    existing_bot_id: str | None = None

    if not token and body.get("botId"):
        saved = get_bot_with_secrets(db, str(body["botId"]))
        if not saved:
            return {"ok": False, "errorCode": 404, "description": "bot not found", "reason": "invalid_request"}, 404
        token = saved["token"]
        existing_bot_id = saved["id"]

    if not token:
        return {
            "ok": False,
            "errorCode": 0,
            "description": "token or botId is required",
            "reason": "invalid_request",
        }, 400

    client = TelegramClient(token)

    def _run() -> dict[str, Any]:
        me = client.get_me()
        try:
            webhook_info = client.get_webhook_info()
        except Exception:
            webhook_info = None

        existing = (
            get_bot_with_secrets(db, existing_bot_id)
            if existing_bot_id
            else find_bot_by_token_or_bot_id(db, token, int(me["id"]))
        )

        active_tasks: list[dict[str, Any]] = []
        total_tasks_count = 0
        rate_limit_info: dict[str, Any] = {
            "is_cooling_down": False,
            "cooldown_until": None,
            "cooldown_seconds_remaining": 0,
            "events_last_24h": 0,
        }

        resolved_existing_id = existing_bot_id
        if existing:
            resolved_existing_id = existing["id"]
            all_tasks = list_tasks_by_bot(db, existing["id"])
            total_tasks_count = len(all_tasks)
            active_tasks = [
                t
                for t in all_tasks
                if t.get("live_enabled") or t.get("backfill_status") in ("running", "paused")
            ]
            rate_limit_info = get_bot_rate_limit_stats(db, existing["id"])

        wh_diag: dict[str, Any] = {
            "is_active": bool(webhook_info and webhook_info.get("url")),
            "pending_update_count": int(webhook_info.get("pending_update_count", 0)) if webhook_info else 0,
        }
        if webhook_info:
            if webhook_info.get("url"):
                wh_diag["url"] = webhook_info["url"]
            if webhook_info.get("last_error_message"):
                wh_diag["last_error_message"] = webhook_info["last_error_message"]
            if webhook_info.get("last_error_date"):
                wh_diag["last_error_date"] = webhook_info["last_error_date"]

        return {
            "bot_id": me["id"],
            "bot_username": me.get("username") or me.get("first_name"),
            "existing_bot_id": resolved_existing_id,
            "active_tasks": active_tasks,
            "total_tasks_count": total_tasks_count,
            "webhook_info": wh_diag,
            "rate_limit_info": rate_limit_info,
        }

    result = to_result(_run)
    return result, (200 if result.get("ok") else 400)


def handle_inspect_bot(body: dict[str, Any], db: Database) -> tuple[dict[str, Any], int]:
    raw_token = body.get("token")
    token = raw_token.strip() if isinstance(raw_token, str) else ""
    existing_bot_id: str | None = None

    if not token and body.get("botId"):
        saved = get_bot_with_secrets(db, str(body["botId"]))
        if not saved:
            return {"ok": False, "errorCode": 404, "description": "bot not found", "reason": "invalid_request"}, 404
        token = saved["token"]
        existing_bot_id = saved["id"]

    if not token:
        return {
            "ok": False,
            "errorCode": 0,
            "description": "token or botId is required",
            "reason": "invalid_request",
        }, 400

    client = TelegramClient(token)

    def _run() -> dict[str, Any]:
        me = client.get_me()
        try:
            webhook_info = client.get_webhook_info()
        except Exception:
            webhook_info = None

        existing = (
            get_bot_with_secrets(db, existing_bot_id)
            if existing_bot_id
            else find_bot_by_token_or_bot_id(db, token, int(me["id"]))
        )

        active_tasks: list[dict[str, Any]] = []
        rate_limit_info: dict[str, Any] = {
            "is_cooling_down": False,
            "cooldown_until": None,
            "cooldown_seconds_remaining": 0,
            "events_last_24h": 0,
        }

        if existing:
            all_tasks = list_tasks_by_bot(db, existing["id"])
            active_tasks = [
                t
                for t in all_tasks
                if t.get("live_enabled") or t.get("backfill_status") in ("running", "paused")
            ]
            rate_limit_info = get_bot_rate_limit_stats(db, existing["id"])

        conflict_detected = False
        conflict_message: str | None = None
        recent_activities: list[dict[str, Any]] = []

        is_webhook_active = bool(webhook_info and webhook_info.get("url"))
        if not is_webhook_active:
            try:
                raw_updates = client.get_updates({"limit": 8})
                if raw_updates:
                    recent_activities = [dict(parse_telegram_update(u)) for u in raw_updates]
            except Exception as exc:
                if isinstance(exc, TelegramApiError) and exc.error_code == 409:
                    conflict_detected = True
                    conflict_message = (
                        str(exc)
                        or "Conflict: terminated by other getUpdates request (another bot script or Pyrogram session is actively running)"
                    )

        wh_diag: dict[str, Any] = {
            "is_active": is_webhook_active,
            "pending_update_count": int(webhook_info.get("pending_update_count", 0)) if webhook_info else 0,
        }
        if webhook_info:
            if webhook_info.get("url"):
                wh_diag["url"] = webhook_info["url"]
            if webhook_info.get("last_error_message"):
                wh_diag["last_error_message"] = webhook_info["last_error_message"]
            if webhook_info.get("last_error_date"):
                wh_diag["last_error_date"] = webhook_info["last_error_date"]

        polling_session: dict[str, Any] = {"conflict_detected": conflict_detected}
        if conflict_message:
            polling_session["message"] = conflict_message

        return {
            "bot_id": me["id"],
            "bot_username": me.get("username") or me.get("first_name"),
            "clone_worker_tasks": {
                "active_count": len(active_tasks),
                "tasks": active_tasks,
            },
            "webhook": wh_diag,
            "polling_session": polling_session,
            "rate_limits": rate_limit_info,
            "recent_activities": recent_activities,
        }

    result = to_result(_run)
    return result, (200 if result.get("ok") else 400)


def handle_disconnect_bot_webhook(body: dict[str, Any], db: Database) -> tuple[dict[str, Any], int]:
    raw_token = body.get("token")
    token = raw_token.strip() if isinstance(raw_token, str) else ""
    if not token and body.get("botId"):
        saved = get_bot_with_secrets(db, str(body["botId"]))
        if not saved:
            return {"ok": False, "errorCode": 404, "description": "bot not found", "reason": "invalid_request"}, 404
        token = saved["token"]
    if not token:
        return {
            "ok": False,
            "errorCode": 0,
            "description": "token or botId is required",
            "reason": "invalid_request",
        }, 400

    client = TelegramClient(token)

    def _run() -> dict[str, Any]:
        client.delete_webhook(False)
        try:
            webhook_info = client.get_webhook_info()
        except Exception:
            webhook_info = None
        return {
            "disconnected": True,
            "pending_updates_preserved": True,
            "pending_update_count": int(webhook_info.get("pending_update_count", 0)) if webhook_info else 0,
        }

    result = to_result(_run)
    return result, (200 if result.get("ok") else 400)


def create_bot_record(db: Database, _origin: str, token: str, label: str | None = None) -> dict[str, Any]:
    client = TelegramClient(token)

    def _run() -> dict[str, Any]:
        me = client.get_me()
        bot_uuid = str(uuid.uuid4())
        webhook_secret = uuid.uuid4().hex
        bot_username = me.get("username") or me.get("first_name")
        bot_label = label or bot_username
        insert_bot(
            db,
            {
                "id": bot_uuid,
                "token": token,
                "bot_id": int(me["id"]),
                "bot_username": bot_username,
                "label": bot_label,
                "webhook_secret": webhook_secret,
            },
        )
        return {
            "id": bot_uuid,
            "bot_id": int(me["id"]),
            "bot_username": bot_username,
            "label": bot_label,
            "created_at": int(time.time()),
        }

    return to_result(_run)


def handle_update_bot(body: dict[str, Any], db: Database, bot_id: str) -> tuple[dict[str, Any], int]:
    label = body.get("label")
    if not label:
        return {"ok": False, "errorCode": 0, "description": "label is required", "reason": "invalid_request"}, 400
    update_bot_label(db, bot_id, str(label))
    return {"ok": True, "data": None}, 200


def handle_delete_bot(db: Database, bot_id: str) -> tuple[dict[str, Any], int]:
    bot = get_bot_with_secrets(db, bot_id)
    if not bot:
        return {"ok": False, "errorCode": 404, "description": "bot not found", "reason": "invalid_request"}, 404
    client = TelegramClient(bot["token"])
    to_result(lambda: client.delete_webhook(False))
    delete_bot(db, bot_id)
    return {"ok": True, "data": None}, 200
