"""Chats API route handlers ported 1:1 from src/routes/api/chats.ts."""
from __future__ import annotations
from typing import Any
from ..db.bootstrap import Database
from ..db.queries import get_bot_with_secrets, list_tasks_for_source_chat
from ..jobs.resolve_range import resolve_last_n
from ..telegram.capabilities import derive_capabilities
from ..telegram.client import TelegramClient
from ..telegram.errors import to_result


def _load_client(db: Database, bot_id: str, token: str) -> TelegramClient | None:
    if token:
        return TelegramClient(token)
    if not bot_id:
        return None
    bot = get_bot_with_secrets(db, bot_id)
    return TelegramClient(bot["token"]) if bot else None


def _load_client_and_bot_id(
    db: Database,
    bot_id: str,
    token: str,
    bot_telegram_id: str,
) -> tuple[TelegramClient, int] | None:
    if token:
        try:
            tg_id = int(bot_telegram_id)
            if not tg_id:
                return None
            return TelegramClient(token), tg_id
        except ValueError:
            return None
    if not bot_id:
        return None
    bot = get_bot_with_secrets(db, bot_id)
    return (TelegramClient(bot["token"]), int(bot["bot_id"])) if bot else None


def handle_get_chat(
    db: Database,
    chat_id: str,
    bot_id: str,
    token: str,
    bot_telegram_id: str,
) -> tuple[dict[str, Any], int]:
    loaded = _load_client_and_bot_id(db, bot_id, token, bot_telegram_id)
    if not loaded:
        return {"ok": False, "errorCode": 404, "description": "bot not found", "reason": "invalid_request"}, 404
    client, telegram_id = loaded

    def _run() -> dict[str, Any]:
        chat = client.get_chat(chat_id)
        member = client.get_chat_member(chat_id, telegram_id)

        member_count = None
        try:
            member_count = client.get_chat_member_count(chat_id)
        except Exception:
            pass

        admins = None
        try:
            admin_data = client.get_chat_administrators(chat_id)
            admins = [
                {
                    "id": a["user"]["id"],
                    "name": a["user"]["first_name"]
                    + (f" (@{a['user']['username']})" if a["user"].get("username") else ""),
                    "status": a["status"],
                    "is_bot": bool(a["user"].get("is_bot")),
                }
                for a in admin_data
            ]
        except Exception:
            pass

        lookup_ids = {str(chat["id"]), chat_id}
        if chat.get("username"):
            lookup_ids.add(f"@{chat['username']}")
        past_tasks = list_tasks_for_source_chat(db, list(lookup_ids))

        res: dict[str, Any] = {
            "chat": {
                "id": chat["id"],
                "type": chat["type"],
                **({"title": chat["title"]} if chat.get("title") else {}),
                **({"username": chat["username"]} if chat.get("username") else {}),
            },
            "botStatus": member["status"],
            "capabilities": derive_capabilities(member, chat["type"]),
            "pastTasks": past_tasks,
        }
        if member_count is not None:
            res["memberCount"] = member_count
        if admins is not None:
            res["admins"] = admins
        return res

    result = to_result(_run)
    return result, (200 if result.get("ok") else 400)


def handle_invite_link(db: Database, chat_id: str, bot_id: str, token: str) -> tuple[dict[str, Any], int]:
    client = _load_client(db, bot_id, token)
    if not client:
        return {"ok": False, "errorCode": 404, "description": "bot not found", "reason": "invalid_request"}, 404
    result = to_result(lambda: client.create_chat_invite_link(chat_id))
    return result, (200 if result.get("ok") else 400)


def handle_revoke_invite_link(
    db: Database, chat_id: str, bot_id: str, invite_link: str, token: str
) -> tuple[dict[str, Any], int]:
    client = _load_client(db, bot_id, token)
    if not client:
        return {"ok": False, "errorCode": 404, "description": "bot not found", "reason": "invalid_request"}, 404
    result = to_result(lambda: client.revoke_chat_invite_link(chat_id, invite_link))
    return result, (200 if result.get("ok") else 400)


def handle_ban(db: Database, chat_id: str, bot_id: str, user_id: int, token: str) -> tuple[dict[str, Any], int]:
    client = _load_client(db, bot_id, token)
    if not client:
        return {"ok": False, "errorCode": 404, "description": "bot not found", "reason": "invalid_request"}, 404
    result = to_result(lambda: client.ban_chat_member(chat_id, user_id))
    return result, (200 if result.get("ok") else 400)


def handle_unban(db: Database, chat_id: str, bot_id: str, user_id: int, token: str) -> tuple[dict[str, Any], int]:
    client = _load_client(db, bot_id, token)
    if not client:
        return {"ok": False, "errorCode": 404, "description": "bot not found", "reason": "invalid_request"}, 404
    result = to_result(lambda: client.unban_chat_member(chat_id, user_id))
    return result, (200 if result.get("ok") else 400)


def handle_promote(
    db: Database, chat_id: str, bot_id: str, user_id: int, rights: dict[str, Any], token: str
) -> tuple[dict[str, Any], int]:
    client = _load_client(db, bot_id, token)
    if not client:
        return {"ok": False, "errorCode": 404, "description": "bot not found", "reason": "invalid_request"}, 404
    result = to_result(lambda: client.promote_chat_member(chat_id, user_id, rights))
    return result, (200 if result.get("ok") else 400)


def handle_send_test_message(
    db: Database, chat_id: str, bot_id: str, text: str, token: str
) -> tuple[dict[str, Any], int]:
    client = _load_client(db, bot_id, token)
    if not client:
        return {"ok": False, "errorCode": 404, "description": "bot not found", "reason": "invalid_request"}, 404
    result = to_result(lambda: client.send_message(chat_id, text))
    return result, (200 if result.get("ok") else 400)


def handle_latest_message_id(db: Database, chat_id: str, bot_id: str, token: str) -> tuple[dict[str, Any], int]:
    client = _load_client(db, bot_id, token)
    if not client:
        return {"ok": False, "errorCode": 404, "description": "bot not found", "reason": "invalid_request"}, 404

    def _run() -> dict[str, Any]:
        resolved = resolve_last_n(client, chat_id, 1)
        return {"latestMessageId": resolved["endId"], "cleanupOk": resolved["cleanupOk"]}

    result = to_result(_run)
    return result, (200 if result.get("ok") else 400)


def handle_ad_hoc_test_copy(
    db: Database,
    source_chat_id: str,
    bot_id: str,
    dest_chat_id: str,
    token: str,
    message_id: int | None = None,
) -> tuple[dict[str, Any], int]:
    client = _load_client(db, bot_id, token)
    if not client:
        return {"ok": False, "errorCode": 404, "description": "bot not found", "reason": "invalid_request"}, 404

    def _run() -> dict[str, Any]:
        copy_id = message_id
        if not copy_id:
            latest = resolve_last_n(client, source_chat_id, 1)
            copy_id = latest["endId"]
        return client.copy_message(dest_chat_id, source_chat_id, copy_id)

    result = to_result(_run)
    return result, (200 if result.get("ok") else 400)
