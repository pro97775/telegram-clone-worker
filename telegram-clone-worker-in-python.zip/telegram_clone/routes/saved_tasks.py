"""Saved Task Templates API route handlers ported 1:1 from src/routes/api/savedTasks.ts."""
from __future__ import annotations
import uuid
from typing import Any
from ..db.bootstrap import Database
from ..db.queries import (
    delete_saved_task,
    get_saved_task,
    insert_saved_task,
    list_saved_tasks,
)


def handle_list_saved_tasks(db: Database) -> tuple[dict[str, Any], int]:
    saved = list_saved_tasks(db)
    return {"ok": True, "data": saved}, 200


def handle_get_saved_task(db: Database, saved_id: str) -> tuple[dict[str, Any], int]:
    saved = get_saved_task(db, saved_id)
    if not saved:
        return {"ok": False, "errorCode": 404, "description": "saved task not found", "reason": "invalid_request"}, 404
    return {"ok": True, "data": saved}, 200


def handle_create_saved_task(body: dict[str, Any], db: Database) -> tuple[dict[str, Any], int]:
    saved_id = str(uuid.uuid4())
    insert_saved_task(db, {**body, "id": saved_id})
    return {"ok": True, "data": {"id": saved_id}}, 201


def handle_delete_saved_task(db: Database, saved_id: str) -> tuple[dict[str, Any], int]:
    delete_saved_task(db, saved_id)
    return {"ok": True, "data": None}, 200
