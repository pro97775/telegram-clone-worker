"""Tasks API route handlers ported 1:1 from src/routes/api/tasks.ts."""
from __future__ import annotations
import uuid
from typing import Any
from ..db.bootstrap import Database
from ..db.queries import (
    delete_task,
    find_duplicate_task,
    get_bot_with_secrets,
    get_task,
    get_task_with_bot,
    insert_saved_task,
    insert_task,
    list_activity_log,
    list_all_tasks_summary,
    list_tasks_by_bot,
    update_task_config,
)
from ..jobs.resolve_range import resolve_last_n
from ..telegram.client import TelegramClient
from ..telegram.errors import to_result
from .bots import create_bot_record

NEW_BOT_SENTINEL = "new"
DEFAULT_PACING_BATCH_SIZE = 60


def handle_list_all_tasks(db: Database) -> tuple[dict[str, Any], int]:
    tasks = list_all_tasks_summary(db)
    return {"ok": True, "data": tasks}, 200


def handle_list_tasks(db: Database, bot_id: str) -> tuple[dict[str, Any], int]:
    tasks = list_tasks_by_bot(db, bot_id)
    return {"ok": True, "data": tasks}, 200


def handle_get_task_by_id(db: Database, task_id: str) -> tuple[dict[str, Any], int]:
    task = get_task_with_bot(db, task_id)
    if not task:
        return {"ok": False, "errorCode": 404, "description": "task not found", "reason": "invalid_request"}, 404
    return {"ok": True, "data": task}, 200


def handle_get_task_activity(db: Database, task_id: str) -> tuple[dict[str, Any], int]:
    log = list_activity_log(db, task_id)
    return {"ok": True, "data": log}, 200


def handle_create_task(
    body: dict[str, Any],
    db: Database,
    bot_id: str,
    origin: str,
) -> tuple[dict[str, Any], int]:
    resolved_bot_id = bot_id
    if bot_id == NEW_BOT_SENTINEL:
        bot_token = body.get("botToken")
        if not bot_token:
            return {"ok": False, "errorCode": 0, "description": "botToken is required", "reason": "invalid_request"}, 400
        created = create_bot_record(db, origin, str(bot_token), body.get("botLabel"))
        if not created.get("ok"):
            return created, 400
        resolved_bot_id = created["data"]["id"]

    bot = get_bot_with_secrets(db, resolved_bot_id)
    if not bot:
        return {"ok": False, "errorCode": 404, "description": "bot not found", "reason": "invalid_request"}, 404

    source_chat_id = str(body.get("sourceChatId", ""))
    dest_chat_id = str(body.get("destChatId", ""))
    duplicate = find_duplicate_task(db, resolved_bot_id, source_chat_id, dest_chat_id)
    if duplicate and not body.get("allowDuplicate"):
        return {
            "ok": False,
            "errorCode": 0,
            "description": "a task with this source and destination already exists",
            "reason": "invalid_request",
            "duplicateTaskId": duplicate["id"],
        }, 409

    scope = body.get("scope", "live")
    wants_backfill = scope in ("live_and_backfill", "backfill_only")
    wants_live = scope in ("live", "live_and_backfill")

    client = TelegramClient(bot["token"])

    def _run() -> dict[str, Any] | None:
        start_id = body.get("startId")
        end_id = body.get("endId")
        backfill_mode = body.get("backfillMode")

        if wants_backfill and backfill_mode == "lastN":
            resolved = resolve_last_n(client, source_chat_id, int(body.get("n") or 1))
            start_id = resolved["startId"]
            end_id = resolved["endId"]

        task_id = str(uuid.uuid4())
        source_title = body.get("sourceChatTitle")
        dest_title = body.get("destChatTitle")
        label = body.get("label") or f"{source_title or source_chat_id} → {dest_title or dest_chat_id}"
        pacing_batch_size = int(body.get("pacingBatchSize") or DEFAULT_PACING_BATCH_SIZE)

        insert_task(
            db,
            {
                "id": task_id,
                "bot_id": resolved_bot_id,
                "label": label,
                "source_chat_id": source_chat_id,
                "source_chat_title": source_title,
                "dest_chat_id": dest_chat_id,
                "dest_chat_title": dest_title,
                "scope": scope,
                "live_enabled": wants_live,
                "backfill_mode": (backfill_mode or "range") if wants_backfill else None,
                "start_id": start_id,
                "end_id": end_id,
                "cursor": start_id if wants_backfill else None,
                "total": (int(end_id) - int(start_id) + 1)
                if (wants_backfill and start_id is not None and end_id is not None)
                else None,
                "backfill_status": "running" if wants_backfill else "not_applicable",
                "pacing_batch_size": pacing_batch_size,
                "filter_media_types": body.get("filterMediaTypes"),
                "filter_min_size_bytes": body.get("filterMinSizeBytes"),
                "filter_max_size_bytes": body.get("filterMaxSizeBytes"),
            },
        )

        if body.get("saveTemplate"):
            try:
                insert_saved_task(
                    db,
                    {
                        "id": str(uuid.uuid4()),
                        "task_id": task_id,
                        "bot_token": bot["token"],
                        "bot_label": bot["label"],
                        "bot_username": bot["bot_username"],
                        "source_chat_id": source_chat_id,
                        "source_chat_title": source_title,
                        "dest_chat_id": dest_chat_id,
                        "dest_chat_title": dest_title,
                        "scope": scope,
                        "backfill_mode": (backfill_mode or "range") if wants_backfill else None,
                        "start_id": start_id,
                        "end_id": end_id,
                        "n": body.get("n") if (wants_backfill and backfill_mode == "lastN") else None,
                        "pacing_batch_size": pacing_batch_size,
                        "filter_media_types": body.get("filterMediaTypes"),
                        "filter_min_size_bytes": body.get("filterMinSizeBytes"),
                        "filter_max_size_bytes": body.get("filterMaxSizeBytes"),
                    },
                )
            except Exception as err:
                print(f"saved_tasks write failed: {err}")

        return get_task(db, task_id)

    result = to_result(_run)
    return result, (201 if result.get("ok") else 400)


def handle_patch_task(body: dict[str, Any], db: Database, task_id: str) -> tuple[dict[str, Any], int]:
    current_task = get_task(db, task_id)
    if not current_task:
        return {"ok": False, "errorCode": 404, "description": "task not found", "reason": "invalid_request"}, 404

    target_scope = body.get("scope") if "scope" in body and body["scope"] is not None else current_task["scope"]
    live_enabled = body.get("liveEnabled")
    backfill_status = body.get("backfillStatus")

    if "scope" in body and body["scope"] is not None:
        if body["scope"] == "live":
            live_enabled = live_enabled if live_enabled is not None else True
            backfill_status = "not_applicable"
        elif body["scope"] == "backfill_only":
            live_enabled = False
            if not backfill_status:
                backfill_status = (
                    "running"
                    if current_task["backfill_status"] == "not_applicable"
                    else current_task["backfill_status"]
                )
        elif body["scope"] == "live_and_backfill":
            live_enabled = live_enabled if live_enabled is not None else True
            if not backfill_status:
                backfill_status = (
                    "running"
                    if current_task["backfill_status"] == "not_applicable"
                    else current_task["backfill_status"]
                )

    start_id = body["startId"] if "startId" in body else current_task["start_id"]
    end_id = body["endId"] if "endId" in body else current_task["end_id"]
    cursor = body["cursor"] if "cursor" in body else current_task["cursor"]
    total = current_task["total"]

    if target_scope != "live":
        if start_id is not None and end_id is not None:
            if int(start_id) > int(end_id):
                return {
                    "ok": False,
                    "errorCode": 400,
                    "description": "startId cannot be greater than endId",
                    "reason": "invalid_request",
                }, 400
            total = int(end_id) - int(start_id) + 1
            if body.get("resetProgress"):
                cursor = start_id
                backfill_status = "running"
            else:
                if cursor is None or int(cursor) < int(start_id):
                    cursor = start_id
                if int(cursor) <= int(end_id) and (
                    current_task["backfill_status"] == "complete" or backfill_status == "complete"
                ):
                    backfill_status = "running"

    filter_media_types = (
        body["filterMediaTypes"] if "filterMediaTypes" in body else current_task["filter_media_types"]
    )
    filter_min_size_bytes = (
        body["filterMinSizeBytes"] if "filterMinSizeBytes" in body else current_task["filter_min_size_bytes"]
    )
    filter_max_size_bytes = (
        body["filterMaxSizeBytes"] if "filterMaxSizeBytes" in body else current_task["filter_max_size_bytes"]
    )

    if target_scope == "backfill_only":
        filter_media_types = None
        filter_min_size_bytes = None
        filter_max_size_bytes = None

    config_patch: dict[str, Any] = {
        "scope": target_scope,
        "start_id": start_id,
        "end_id": end_id,
        "cursor": cursor,
        "total": total,
        "reset_progress": bool(body.get("resetProgress")),
        "filter_media_types": filter_media_types,
        "filter_min_size_bytes": filter_min_size_bytes,
        "filter_max_size_bytes": filter_max_size_bytes,
    }
    if "label" in body and body["label"] is not None:
        config_patch["label"] = body["label"]
    if live_enabled is not None:
        config_patch["live_enabled"] = live_enabled
    if backfill_status is not None:
        config_patch["backfill_status"] = backfill_status

    update_task_config(db, task_id, config_patch)
    task = get_task(db, task_id)
    return {"ok": True, "data": task}, 200


def handle_delete_task(db: Database, task_id: str) -> tuple[dict[str, Any], int]:
    delete_task(db, task_id)
    return {"ok": True, "data": None}, 200


def handle_test_copy(
    db: Database,
    bot_id: str,
    task_id: str,
    message_id: int | None = None,
) -> tuple[dict[str, Any], int]:
    bot = get_bot_with_secrets(db, bot_id)
    task = get_task(db, task_id)
    if not bot or not task:
        return {"ok": False, "errorCode": 404, "description": "not found", "reason": "invalid_request"}, 404

    client = TelegramClient(bot["token"])

    def _run() -> dict[str, Any]:
        copy_id = message_id
        if not copy_id:
            latest = resolve_last_n(client, task["source_chat_id"], 1)
            copy_id = latest["endId"]
        return client.copy_message(task["dest_chat_id"], task["source_chat_id"], copy_id)

    result = to_result(_run)
    return result, (200 if result.get("ok") else 400)
