"""Shared utilities and RPC types."""
