"""Fixed-size concurrency pool ported 1:1 from src/shared/concurrencyPool.ts."""
from __future__ import annotations
from concurrent.futures import ThreadPoolExecutor
from typing import Callable, Sequence, TypeVar

T = TypeVar("T")
R = TypeVar("R")


def run_with_concurrency(
    items: Sequence[T],
    limit: int,
    worker: Callable[[T, int], R],
) -> list[R]:
    """Runs `worker(item, index)` over `items` with at most `limit` in flight at once."""
    if not items:
        return []
    max_workers = max(1, min(limit, len(items)))
    results: list[R] = [None] * len(items)  # type: ignore[list-item]

    def _task(idx_and_item: tuple[int, T]) -> None:
        idx, item = idx_and_item
        results[idx] = worker(item, idx)

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        list(executor.map(_task, enumerate(items)))

    return results
