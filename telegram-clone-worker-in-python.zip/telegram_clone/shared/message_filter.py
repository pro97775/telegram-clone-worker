"""Message media & file-size filter utilities ported 1:1 from src/shared/messageFilter.ts."""
from __future__ import annotations
import math
from typing import Any, TypedDict


class MessageFilterCriteria(TypedDict, total=False):
    mediaTypes: list[str] | None
    minSizeBytes: int | None
    maxSizeBytes: int | None


class ExtractedMetadata(TypedDict, total=False):
    type: str
    size: int | None
    name: str | None
    mimeType: str | None


class FilterEvaluation(TypedDict, total=False):
    matched: bool
    detectedType: str
    detectedSize: int | None
    detectedName: str | None
    reason: str | None


def extract_message_metadata(msg: dict[str, Any]) -> ExtractedMetadata:
    """Extracts standardized media type, file size, and file name from a TelegramMessage."""
    if msg.get("document"):
        doc = msg["document"]
        return {
            "type": "document",
            "size": doc.get("file_size"),
            "name": doc.get("file_name"),
            "mimeType": doc.get("mime_type"),
        }
    if msg.get("video"):
        vid = msg["video"]
        return {
            "type": "video",
            "size": vid.get("file_size"),
            "name": vid.get("file_name"),
            "mimeType": vid.get("mime_type"),
        }
    if msg.get("animation"):
        anim = msg["animation"]
        return {
            "type": "animation",
            "size": anim.get("file_size"),
            "name": anim.get("file_name"),
            "mimeType": anim.get("mime_type"),
        }
    if msg.get("audio"):
        aud = msg["audio"]
        return {
            "type": "audio",
            "size": aud.get("file_size"),
            "name": aud.get("file_name"),
            "mimeType": aud.get("mime_type"),
        }
    if msg.get("voice"):
        vc = msg["voice"]
        return {
            "type": "voice",
            "size": vc.get("file_size"),
            "mimeType": vc.get("mime_type"),
        }
    photos = msg.get("photo")
    if isinstance(photos, list) and len(photos) > 0:
        largest = photos[-1]
        return {
            "type": "photo",
            "size": largest.get("file_size"),
        }
    return {
        "type": "text",
    }


def format_bytes(num_bytes: int | float | None = None) -> str:
    """Converts byte values to human-readable string (e.g. 14.5 MB, 1.2 GB)."""
    if num_bytes is None or num_bytes == 0:
        return "0 B"
    k = 1024
    sizes = ["B", "KB", "MB", "GB"]
    i = int(math.floor(math.log(num_bytes) / math.log(k)))
    val = round(num_bytes / math.pow(k, i), 1)
    if val == int(val):
        val_str = str(int(val))
    else:
        val_str = str(val)
    unit = sizes[i] if 0 <= i < len(sizes) else "B"
    return f"{val_str} {unit}"


def get_media_icon(media_type: str) -> str:
    """Returns an emoji icon and label for a media type."""
    mapping = {
        "video": "🎬 Video",
        "document": "📄 Document",
        "photo": "🖼️ Photo",
        "audio": "🎵 Audio",
        "voice": "🎙️ Voice",
        "animation": "🎭 GIF",
    }
    return mapping.get(media_type, "💬 Text")


def evaluate_message_filter(
    msg: dict[str, Any],
    criteria: MessageFilterCriteria,
) -> FilterEvaluation:
    """Evaluates whether a TelegramMessage satisfies the specified filter criteria."""
    meta = extract_message_metadata(msg)
    media_type = meta["type"]
    size = meta.get("size")
    name = meta.get("name")

    media_types = criteria.get("mediaTypes")
    if media_types and len(media_types) > 0:
        if media_type not in media_types:
            reason = "text-only not allowed" if media_type == "text" else f"{media_type}s filtered out"
            return {
                "matched": False,
                "detectedType": media_type,
                "detectedSize": size,
                "detectedName": name,
                "reason": reason,
            }

    min_size = criteria.get("minSizeBytes")
    if min_size is not None and size is not None:
        if size < min_size:
            return {
                "matched": False,
                "detectedType": media_type,
                "detectedSize": size,
                "detectedName": name,
                "reason": f"below min size {format_bytes(min_size)}",
            }

    max_size = criteria.get("maxSizeBytes")
    if max_size is not None and size is not None:
        if size > max_size:
            return {
                "matched": False,
                "detectedType": media_type,
                "detectedSize": size,
                "detectedName": name,
                "reason": f"above max size {format_bytes(max_size)}",
            }

    return {
        "matched": True,
        "detectedType": media_type,
        "detectedSize": size,
        "detectedName": name,
    }
