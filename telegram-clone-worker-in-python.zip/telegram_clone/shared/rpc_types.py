"""RPC and shared types ported 1:1 from src/shared/rpcTypes.ts."""
from __future__ import annotations
from typing import Any, Literal, TypedDict, Union

ErrorReason = Literal[
    "insufficient_permissions",
    "bot_not_in_chat",
    "rate_limited",
    "invalid_request",
    "unauthorized",
    "unknown",
]

TaskScope = Literal["live", "live_and_backfill", "backfill_only"]

BackfillStatus = Literal[
    "not_applicable",
    "pending",
    "running",
    "paused",
    "complete",
    "cancelled",
    "failed",
]

AuthMode = Literal["enforced", "open"]
AuthSource = Literal["env", "d1", "none"]


class OkResult(TypedDict):
    ok: Literal[True]
    data: Any


class ErrResult(TypedDict, total=False):
    ok: Literal[False]
    errorCode: int
    description: str
    reason: ErrorReason
    retryAfter: int


Result = Union[OkResult, ErrResult]


class BotSummary(TypedDict):
    id: str
    bot_id: int
    bot_username: str
    label: str
    created_at: int


class BotWebhookDiagnostics(TypedDict, total=False):
    is_active: bool
    url: str
    pending_update_count: int
    last_error_message: str
    last_error_date: int


class BotRateLimitDiagnostics(TypedDict):
    is_cooling_down: bool
    cooldown_seconds_remaining: int
    cooldown_until: int | None
    events_last_24h: int


class TaskSummary(TypedDict, total=False):
    id: str
    bot_id: str
    label: str
    source_chat_id: str
    source_chat_title: str | None
    dest_chat_id: str
    dest_chat_title: str | None
    scope: TaskScope
    live_enabled: bool
    backfill_mode: Literal["range", "lastN"] | None
    start_id: int | None
    end_id: int | None
    cursor: int | None
    total: int | None
    processed: int
    failed: int
    live_processed: int
    live_failed: int
    live_skipped: int
    filter_media_types: str | None
    filter_min_size_bytes: int | None
    filter_max_size_bytes: int | None
    pending_count: int
    backfill_status: BackfillStatus
    pacing_batch_size: int
    stop_reason: ErrorReason | None
    stopped_at: int | None
    rate_limited_until: int | None
    created_at: int


class TaskDetail(TaskSummary):
    bot_username: str


class CapabilityEntry(TypedDict, total=False):
    key: str
    label: str
    available: bool
    reason: str
