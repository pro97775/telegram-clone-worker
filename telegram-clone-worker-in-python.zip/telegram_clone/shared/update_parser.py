"""Telegram update parser ported 1:1 from src/shared/updateParser.ts."""
from __future__ import annotations
from datetime import datetime, timezone
from typing import Any, Literal, TypedDict
from .message_filter import format_bytes


class ParsedBotActivity(TypedDict, total=False):
    update_id: int
    kind: Literal["command", "document", "media", "text", "channel_post", "member_event", "other"]
    icon: str
    summary: str
    chat_name: str
    chat_type: str
    sender_name: str | None
    date_iso: str | None


def _to_iso(timestamp: int | None) -> str | None:
    if not timestamp:
        return None
    return datetime.fromtimestamp(timestamp, tz=timezone.utc).isoformat().replace("+00:00", ".000Z")


def parse_telegram_update(update: dict[str, Any]) -> ParsedBotActivity:
    """Parses raw Telegram updates into intuitive, plain-English activity summaries."""
    update_id = int(update.get("update_id", 0))
    msg = update.get("message") or update.get("channel_post") or update.get("edited_message")

    if update.get("my_chat_member"):
        mem = update["my_chat_member"]
        from_user = mem.get("from", {})
        actor = f"@{from_user['username']}" if from_user.get("username") else from_user.get("first_name", "Unknown")
        chat = mem.get("chat", {})
        chat_title = chat.get("title") or (f"@{chat['username']}" if chat.get("username") else f"Chat #{chat.get('id')}")
        new_status = mem.get("new_chat_member", {}).get("status", "unknown")
        return {
            "update_id": update_id,
            "kind": "member_event",
            "icon": "👤",
            "summary": f"Bot permissions changed to '{new_status}' by {actor}",
            "chat_name": chat_title,
            "chat_type": chat.get("type", "unknown"),
            "sender_name": actor,
            "date_iso": _to_iso(mem.get("date")),
        }

    if update.get("chat_member"):
        mem = update["chat_member"]
        new_member = mem.get("new_chat_member", {})
        target_user_obj = new_member.get("user", {})
        target_user = (
            f"@{target_user_obj['username']}"
            if target_user_obj.get("username")
            else target_user_obj.get("first_name", "User")
        )
        chat = mem.get("chat", {})
        chat_title = chat.get("title") or (f"@{chat['username']}" if chat.get("username") else f"Chat #{chat.get('id')}")
        new_status = new_member.get("status", "unknown")
        return {
            "update_id": update_id,
            "kind": "member_event",
            "icon": "👥",
            "summary": f"User {target_user} became '{new_status}' in chat",
            "chat_name": chat_title,
            "chat_type": chat.get("type", "unknown"),
            "date_iso": _to_iso(mem.get("date")),
        }

    if not msg:
        return {
            "update_id": update_id,
            "kind": "other",
            "icon": "⚡",
            "summary": "System notification or callback event",
            "chat_name": "Unknown",
            "chat_type": "unknown",
        }

    from_user = msg.get("from")
    if from_user:
        sender = f"@{from_user['username']}" if from_user.get("username") else from_user.get("first_name", "User")
    elif update.get("channel_post"):
        sender = "Channel Post"
    else:
        sender = "Anonymous"

    chat = msg.get("chat", {})
    chat_title = chat.get("title") or (f"@{chat['username']}" if chat.get("username") else f"Chat #{chat.get('id')}")
    chat_type = chat.get("type", "unknown")
    is_post = bool(update.get("channel_post"))
    date_iso = _to_iso(msg.get("date"))

    text = msg.get("text")
    # 1. Bot Commands (e.g. /start, /copy, /help)
    if isinstance(text, str) and text.startswith("/"):
        parts = text.strip().split()
        cmd = parts[0]
        args = " ".join(parts[1:])
        args_snippet = f"{args[:30]}…" if len(args) > 30 else args
        args_part = f' with arguments "{args_snippet}"' if args else ""
        return {
            "update_id": update_id,
            "kind": "command",
            "icon": "⚙️",
            "summary": f"Received command {cmd}{args_part} from {sender}",
            "chat_name": chat_title,
            "chat_type": chat_type,
            "sender_name": sender,
            "date_iso": date_iso,
        }

    # 2. Documents / Files
    if msg.get("document"):
        doc = msg["document"]
        name = doc.get("file_name") or "unnamed file"
        size_str = f" ({format_bytes(doc['file_size'])})" if doc.get("file_size") else ""
        return {
            "update_id": update_id,
            "kind": "document",
            "icon": "📁",
            "summary": f"Received file '{name}'{size_str} from {sender}",
            "chat_name": chat_title,
            "chat_type": chat_type,
            "sender_name": sender,
            "date_iso": date_iso,
        }

    # 3. Videos
    if msg.get("video"):
        vid = msg["video"]
        size_str = f" ({format_bytes(vid['file_size'])})" if vid.get("file_size") else ""
        dur_str = f" [{vid['duration']}s]" if vid.get("duration") else ""
        return {
            "update_id": update_id,
            "kind": "media",
            "icon": "🎬",
            "summary": f"Received video{dur_str}{size_str} from {sender}",
            "chat_name": chat_title,
            "chat_type": chat_type,
            "sender_name": sender,
            "date_iso": date_iso,
        }

    # 4. Photos
    if isinstance(msg.get("photo"), list) and len(msg["photo"]) > 0:
        caption = msg.get("caption")
        if caption:
            cap_trunc = f"{caption[:40]}…" if len(caption) > 40 else caption
            caption_snippet = f' "{cap_trunc}"'
        else:
            caption_snippet = ""
        return {
            "update_id": update_id,
            "kind": "media",
            "icon": "🖼️",
            "summary": f"Received photo{caption_snippet} from {sender}",
            "chat_name": chat_title,
            "chat_type": chat_type,
            "sender_name": sender,
            "date_iso": date_iso,
        }

    # 5. Audio / Voice / Animation
    if msg.get("audio"):
        aud = msg["audio"]
        name = aud.get("file_name") or "audio track"
        size_str = f" ({format_bytes(aud['file_size'])})" if aud.get("file_size") else ""
        return {
            "update_id": update_id,
            "kind": "media",
            "icon": "🎵",
            "summary": f"Received audio '{name}'{size_str} from {sender}",
            "chat_name": chat_title,
            "chat_type": chat_type,
            "sender_name": sender,
            "date_iso": date_iso,
        }

    if msg.get("voice"):
        vc = msg["voice"]
        dur_str = f" ({vc['duration']}s)" if vc.get("duration") else ""
        return {
            "update_id": update_id,
            "kind": "media",
            "icon": "🎤",
            "summary": f"Received voice message{dur_str} from {sender}",
            "chat_name": chat_title,
            "chat_type": chat_type,
            "sender_name": sender,
            "date_iso": date_iso,
        }

    if msg.get("animation"):
        return {
            "update_id": update_id,
            "kind": "media",
            "icon": "🎞️",
            "summary": f"Received GIF / animation from {sender}",
            "chat_name": chat_title,
            "chat_type": chat_type,
            "sender_name": sender,
            "date_iso": date_iso,
        }

    # 6. Plain Text / Channel Posts
    raw_text = msg.get("text") or msg.get("caption") or ""
    snippet = f"{raw_text[:60]}…" if len(raw_text) > 60 else raw_text

    if is_post:
        return {
            "update_id": update_id,
            "kind": "channel_post",
            "icon": "📢",
            "summary": f'Published channel post: "{snippet}"' if snippet else "Published channel post",
            "chat_name": chat_title,
            "chat_type": chat_type,
            "date_iso": date_iso,
        }

    return {
        "update_id": update_id,
        "kind": "text",
        "icon": "💬",
        "summary": f'Message from {sender}: "{snippet}"' if snippet else f"Message received from {sender}",
        "chat_name": chat_title,
        "chat_type": chat_type,
        "sender_name": sender,
        "date_iso": date_iso,
    }
