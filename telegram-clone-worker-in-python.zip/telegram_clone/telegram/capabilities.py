"""Bot chat capability evaluation ported 1:1 from src/telegram/capabilities.ts."""
from __future__ import annotations
from typing import Any
from ..shared.rpc_types import CapabilityEntry


def derive_capabilities(bot_member: dict[str, Any], chat_type: str) -> list[CapabilityEntry]:
    status = bot_member.get("status", "")
    is_creator = status == "creator"
    is_admin = status == "administrator" or is_creator

    def has_right(right: str) -> bool:
        return is_creator or (is_admin and bool(bot_member.get(right)))

    can_send = (status == "member" or is_admin) and (
        chat_type != "channel" or has_right("can_post_messages")
    )

    entries: list[CapabilityEntry] = []

    def add_entry(key: str, label: str, available: bool, missing_reason: str) -> None:
        item: CapabilityEntry = {"key": key, "label": label, "available": available}
        if not available:
            item["reason"] = missing_reason
        entries.append(item)

    add_entry(
        "invite_link",
        "Generate invite link",
        has_right("can_invite_users"),
        "bot lacks the 'Add Users' admin right in this chat",
    )
    add_entry(
        "ban",
        "Ban / unban user",
        has_right("can_restrict_members"),
        "bot lacks the 'Restrict Members' admin right in this chat",
    )
    add_entry(
        "promote",
        "Promote member",
        has_right("can_promote_members"),
        "bot lacks the 'Add New Admins' admin right in this chat",
    )
    add_entry(
        "send_message",
        "Send message",
        can_send,
        "bot cannot post in this chat (not a member with send rights)",
    )
    add_entry(
        "delete_message",
        "Delete message (used by the 'last N' probe)",
        has_right("can_delete_messages"),
        "bot lacks the 'Delete Messages' admin right in this chat",
    )
    return entries
