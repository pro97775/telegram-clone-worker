"""Telegram Bot API HTTP Client ported 1:1 from src/telegram/client.ts."""
from __future__ import annotations
import json
import urllib.error
import urllib.request
from typing import Any
from .errors import TelegramApiError

API_ROOT = "https://api.telegram.org"


class TelegramClient:
    """Thin wrapper around the Telegram Bot HTTP API."""

    def __init__(self, token: str) -> None:
        self.token = token

    def _call(self, method: str, params: dict[str, Any] | None = None) -> Any:
        url = f"{API_ROOT}/bot{self.token}/{method}"
        clean_params = {k: v for k, v in (params or {}).items() if v is not None}
        payload = json.dumps(clean_params).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=payload,
            headers={"content-type": "application/json"},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=25) as resp:
                raw = resp.read().decode("utf-8")
                body = json.loads(raw)
        except urllib.error.HTTPError as http_err:
            try:
                raw = http_err.read().decode("utf-8")
                body = json.loads(raw)
            except Exception:
                body = {
                    "ok": False,
                    "error_code": http_err.code,
                    "description": f"HTTP {http_err.code}: {http_err.reason}",
                }
        if not body.get("ok"):
            raise TelegramApiError(body)
        return body.get("result")

    def get_me(self) -> dict[str, Any]:
        return self._call("getMe")

    def set_webhook(self, url: str, secret_token: str) -> bool:
        return self._call(
            "setWebhook",
            {
                "url": url,
                "secret_token": secret_token,
                "max_connections": 40,
                "allowed_updates": ["message", "channel_post"],
            },
        )

    def delete_webhook(self, drop_pending_updates: bool = False) -> bool:
        return self._call("deleteWebhook", {"drop_pending_updates": drop_pending_updates})

    def get_webhook_info(self) -> dict[str, Any]:
        return self._call("getWebhookInfo")

    def get_updates(self, params: dict[str, Any] | None = None) -> list[dict[str, Any]]:
        return self._call("getUpdates", params or {})

    def get_chat(self, chat_id: str | int) -> dict[str, Any]:
        return self._call("getChat", {"chat_id": chat_id})

    def get_chat_member_count(self, chat_id: str | int) -> int:
        return self._call("getChatMemberCount", {"chat_id": chat_id})

    def get_chat_member(self, chat_id: str | int, user_id: int) -> dict[str, Any]:
        return self._call("getChatMember", {"chat_id": chat_id, "user_id": user_id})

    def get_chat_administrators(self, chat_id: str | int) -> list[dict[str, Any]]:
        return self._call("getChatAdministrators", {"chat_id": chat_id})

    def create_chat_invite_link(self, chat_id: str | int, name: str | None = None) -> dict[str, Any]:
        return self._call("createChatInviteLink", {"chat_id": chat_id, "name": name})

    def revoke_chat_invite_link(self, chat_id: str | int, invite_link: str) -> dict[str, Any]:
        return self._call("revokeChatInviteLink", {"chat_id": chat_id, "invite_link": invite_link})

    def export_chat_invite_link(self, chat_id: str | int) -> str:
        return self._call("exportChatInviteLink", {"chat_id": chat_id})

    def promote_chat_member(self, chat_id: str | int, user_id: int, rights: dict[str, Any]) -> bool:
        return self._call("promoteChatMember", {"chat_id": chat_id, "user_id": user_id, **rights})

    def ban_chat_member(self, chat_id: str | int, user_id: int) -> bool:
        return self._call("banChatMember", {"chat_id": chat_id, "user_id": user_id})

    def unban_chat_member(self, chat_id: str | int, user_id: int) -> bool:
        return self._call("unbanChatMember", {"chat_id": chat_id, "user_id": user_id, "only_if_banned": True})

    def send_message(self, chat_id: str | int, text: str) -> dict[str, Any]:
        return self._call("sendMessage", {"chat_id": chat_id, "text": text})

    def delete_message(self, chat_id: str | int, message_id: int) -> bool:
        return self._call("deleteMessage", {"chat_id": chat_id, "message_id": message_id})

    def copy_message(self, dest_chat_id: str | int, source_chat_id: str | int, message_id: int) -> dict[str, Any]:
        return self._call(
            "copyMessage",
            {"chat_id": dest_chat_id, "from_chat_id": source_chat_id, "message_id": message_id},
        )

    def copy_messages(
        self, dest_chat_id: str | int, source_chat_id: str | int, message_ids: list[int]
    ) -> list[dict[str, Any]]:
        return self._call(
            "copyMessages",
            {"chat_id": dest_chat_id, "from_chat_id": source_chat_id, "message_ids": message_ids},
        )
