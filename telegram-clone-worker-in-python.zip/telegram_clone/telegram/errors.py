"""Telegram API error classification ported 1:1 from src/telegram/errors.ts."""
from __future__ import annotations
from typing import Any, Callable, TypeVar
from ..shared.rpc_types import ErrorReason

T = TypeVar("T")


def classify(body: dict[str, Any]) -> ErrorReason:
    desc = str(body.get("description", "")).lower()
    error_code = int(body.get("error_code", 0))
    if error_code == 429 or "too many requests" in desc:
        return "rate_limited"
    if error_code == 401:
        return "unauthorized"
    if error_code == 403 or "bot was kicked" in desc or "bot is not a member" in desc:
        return "bot_not_in_chat"
    if (
        "not enough rights" in desc
        or "chat_admin_required" in desc
        or "have no rights" in desc
        or "can't remove chat owner" in desc
        or "user_not_participant" in desc
    ):
        return "insufficient_permissions"
    if error_code == 400:
        return "invalid_request"
    return "unknown"


class TelegramApiError(Exception):
    error_code: int
    reason: ErrorReason
    retry_after: int | None

    def __init__(self, body: dict[str, Any]) -> None:
        description = str(body.get("description", "Telegram API Error"))
        super().__init__(description)
        self.error_code = int(body.get("error_code", 0))
        params = body.get("parameters") or {}
        self.retry_after = params.get("retry_after")
        self.reason = classify(body)


def err_from_telegram(exc: Exception) -> dict[str, Any]:
    if isinstance(exc, TelegramApiError):
        res: dict[str, Any] = {
            "ok": False,
            "errorCode": exc.error_code,
            "description": str(exc),
            "reason": exc.reason,
        }
        if exc.retry_after is not None:
            res["retryAfter"] = exc.retry_after
        return res
    return {
        "ok": False,
        "errorCode": 0,
        "description": str(exc),
        "reason": "unknown",
    }


def to_result(fn: Callable[[], T]) -> dict[str, Any]:
    try:
        data = fn()
        return {"ok": True, "data": data}
    except Exception as exc:
        return err_from_telegram(exc)
