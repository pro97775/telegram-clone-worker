"""Telegram Bot API data types ported 1:1 from src/telegram/types.ts."""
from __future__ import annotations
from typing import Any, Literal, TypedDict

TelegramChatType = Literal["private", "group", "supergroup", "channel"]

ChatMemberStatus = Literal[
    "creator",
    "administrator",
    "member",
    "restricted",
    "left",
    "kicked",
]


class TelegramChat(TypedDict, total=False):
    id: int
    type: TelegramChatType
    title: str
    username: str
    first_name: str
    last_name: str


class TelegramUser(TypedDict, total=False):
    id: int
    is_bot: bool
    first_name: str
    username: str
    can_read_all_group_messages: bool


class TelegramChatMember(TypedDict, total=False):
    status: ChatMemberStatus
    user: TelegramUser
    can_be_edited: bool
    can_manage_chat: bool
    can_delete_messages: bool
    can_manage_video_chats: bool
    can_restrict_members: bool
    can_promote_members: bool
    can_change_info: bool
    can_invite_users: bool
    can_post_messages: bool
    can_edit_messages: bool
    can_pin_messages: bool


class TelegramApiErrorBody(TypedDict, total=False):
    ok: Literal[False]
    error_code: int
    description: str
    parameters: dict[str, Any]
