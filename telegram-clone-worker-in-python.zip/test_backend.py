"""Unit tests for the Python port of Telegram Clone Worker."""
from __future__ import annotations
import time
import unittest

from app import build_python_project_zip_bytes, dispatch_api_request
from telegram_clone.auth.crypto import (
    generate_salt,
    hash_password,
    sign_session_token,
    timing_safe_string_compare,
    verify_session_token,
)
from telegram_clone.db.bootstrap import Database, ensure_database_bootstrap
from telegram_clone.db.queries import (
    advance_task_progress,
    append_activity_log,
    claim_task,
    get_task,
    insert_bot,
    insert_pending_message,
    insert_task,
    list_activity_log,
    list_bots_summary,
    list_pending_messages,
    release_task_lease,
)
from telegram_clone.shared.message_filter import (
    evaluate_message_filter,
    extract_message_metadata,
    format_bytes,
    get_media_icon,
)
from telegram_clone.shared.update_parser import parse_telegram_update
from telegram_clone.telegram.capabilities import derive_capabilities
from telegram_clone.telegram.errors import TelegramApiError, classify


class TestTelegramClonePythonBackend(unittest.TestCase):
    def test_crypto_password_and_session_token(self) -> None:
        salt = generate_salt()
        self.assertEqual(len(salt), 32)
        h1 = hash_password("secret1234", salt)
        h2 = hash_password("secret1234", salt)
        self.assertEqual(h1, h2)
        self.assertTrue(timing_safe_string_compare(h1, h2))
        self.assertFalse(timing_safe_string_compare(h1, "different"))

        now_ms = int(time.time() * 1000)
        token = sign_session_token(
            {"sub": "admin", "iat": now_ms, "exp": now_ms + 60_000},
            "super-secret-key",
        )
        verified = verify_session_token(token, "super-secret-key")
        self.assertTrue(verified["valid"])
        self.assertEqual(verified["payload"]["sub"], "admin")

        invalid = verify_session_token(token, "wrong-key")
        self.assertFalse(invalid["valid"])

    def test_message_filter_and_formatting(self) -> None:
        self.assertEqual(format_bytes(0), "0 B")
        self.assertEqual(format_bytes(1024), "1 KB")
        self.assertEqual(get_media_icon("video"), "🎬 Video")

        video_msg = {
            "message_id": 42,
            "video": {"file_id": "v1", "file_size": 10 * 1024 * 1024, "file_name": "clip.mp4"},
        }
        meta = extract_message_metadata(video_msg)
        self.assertEqual(meta["type"], "video")
        self.assertEqual(meta["name"], "clip.mp4")

        matched = evaluate_message_filter(
            video_msg,
            {"mediaTypes": ["video", "document"], "minSizeBytes": 5 * 1024 * 1024},
        )
        self.assertTrue(matched["matched"])

        rejected = evaluate_message_filter(
            video_msg,
            {"mediaTypes": ["document"]},
        )
        self.assertFalse(rejected["matched"])
        self.assertEqual(rejected["reason"], "videos filtered out")

    def test_update_parser_and_capabilities(self) -> None:
        cmd_update = {
            "update_id": 101,
            "message": {
                "message_id": 1,
                "date": 1700000000,
                "chat": {"id": -1001, "type": "supergroup", "title": "Dev Group"},
                "from": {"id": 99, "is_bot": False, "first_name": "Alice", "username": "alice"},
                "text": "/copy 100 200",
            },
        }
        parsed = parse_telegram_update(cmd_update)
        self.assertEqual(parsed["kind"], "command")
        self.assertIn("/copy", parsed["summary"])
        self.assertEqual(parsed["sender_name"], "@alice")

        caps = derive_capabilities(
            {"status": "administrator", "can_post_messages": True, "can_delete_messages": True},
            "channel",
        )
        cap_map = {c["key"]: c["available"] for c in caps}
        self.assertTrue(cap_map["send_message"])
        self.assertTrue(cap_map["delete_message"])
        self.assertFalse(cap_map["invite_link"])

    def test_error_classification(self) -> None:
        err = TelegramApiError(
            {
                "ok": False,
                "error_code": 429,
                "description": "Too Many Requests: retry after 35",
                "parameters": {"retry_after": 35},
            }
        )
        self.assertEqual(err.reason, "rate_limited")
        self.assertEqual(err.retry_after, 35)
        self.assertEqual(
            classify({"error_code": 403, "description": "Forbidden: bot was kicked from the channel chat"}),
            "bot_not_in_chat",
        )

    def test_database_queries_and_api_routes(self) -> None:
        db = Database(":memory:")
        ensure_database_bootstrap(db)

        # Health check
        res, status = dispatch_api_request("GET", "/api/health", {}, {}, {}, db)
        self.assertEqual(status, 200)
        self.assertEqual(res["data"]["status"], "up")

        # Auth status (open mode initially)
        res, status = dispatch_api_request("GET", "/api/auth/status", {}, {}, {}, db)
        self.assertEqual(status, 200)
        self.assertEqual(res["data"]["mode"], "open")
        self.assertTrue(res["data"]["authenticated"])

        # Insert bot & task directly and test lease + progress
        insert_bot(
            db,
            {
                "id": "bot-1",
                "token": "123456:ABCDEF",
                "bot_id": 123456,
                "bot_username": "clone_test_bot",
                "label": "Primary Clone Bot",
                "webhook_secret": "sec123",
            },
        )
        bots = list_bots_summary(db)
        self.assertEqual(len(bots), 1)
        self.assertEqual(bots[0]["bot_username"], "clone_test_bot")

        insert_task(
            db,
            {
                "id": "task-1",
                "bot_id": "bot-1",
                "label": "Archive Channel -> Mirror Channel",
                "source_chat_id": "-100111",
                "source_chat_title": "Archive Channel",
                "dest_chat_id": "-100222",
                "dest_chat_title": "Mirror Channel",
                "scope": "live_and_backfill",
                "live_enabled": True,
                "backfill_mode": "range",
                "start_id": 1,
                "end_id": 100,
                "cursor": 1,
                "total": 100,
                "backfill_status": "running",
                "pacing_batch_size": 50,
            },
        )

        claimed = claim_task(db, "task-1", 55)
        self.assertIsNotNone(claimed)
        # Second claim while leased should return None
        self.assertIsNone(claim_task(db, "task-1", 55))
        release_task_lease(db, "task-1")

        prog = advance_task_progress(db, "task-1", {"cursor": 101, "processed": 98, "failed": 2})
        self.assertTrue(prog["complete"])
        self.assertEqual(prog["backfill_status"], "complete")

        updated_task = get_task(db, "task-1")
        self.assertIsNotNone(updated_task)
        self.assertEqual(updated_task["processed"], 98)

        append_activity_log(
            db,
            {"task_id": "task-1", "kind": "backfill_batch", "detail": "ids 1-100: 98 ok", "ok": True},
        )
        logs = list_activity_log(db, "task-1")
        self.assertEqual(len(logs), 1)

        insert_pending_message(db, "task-1", 105, "video", 4096, "demo.mp4")
        self.assertEqual(len(list_pending_messages(db, "task-1")), 1)

        # Verify API task listing & patching
        tasks_res, status = dispatch_api_request("GET", "/api/tasks", {}, {}, {}, db)
        self.assertEqual(status, 200)
        self.assertEqual(len(tasks_res["data"]), 1)

        patch_res, status = dispatch_api_request(
            "PATCH",
            "/api/tasks/task-1",
            {},
            {},
            {"liveEnabled": False, "backfillStatus": "paused"},
            db,
        )
        self.assertEqual(status, 200)
        self.assertFalse(patch_res["data"]["live_enabled"])

        # Verify Auth Setup -> Enforced -> Login -> Remove
        setup_res, status = dispatch_api_request("POST", "/api/auth/setup", {}, {}, {"password": "adminpass"}, db)
        self.assertEqual(status, 200)
        token = setup_res["data"]["token"]

        # Unauthenticated request to /api/tasks should now return 401
        unauth_res, status = dispatch_api_request("GET", "/api/tasks", {}, {}, {}, db)
        self.assertEqual(status, 401)

        # Authenticated request with Bearer token succeeds
        authed_res, status = dispatch_api_request(
            "GET",
            "/api/tasks",
            {},
            {"Authorization": f"Bearer {token}"},
            {},
            db,
        )
        self.assertEqual(status, 200)

        # Zip builder produces valid non-empty zip bytes
        zip_bytes = build_python_project_zip_bytes()
        self.assertGreater(len(zip_bytes), 1000)


if __name__ == "__main__":
    unittest.main()
